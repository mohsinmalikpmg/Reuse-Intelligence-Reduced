# Management Reporting Agent

A corporate finance reporting application built with React, FastAPI and SQLite.
All displayed finance data is illustrative, generated deterministically on first startup.

## Run

Use the existing Management Reporting web and API Server workflows. The API runs
`pnpm --filter @workspace/api-server run dev` (Python/Uvicorn); the frontend runs
`pnpm --filter @workspace/management-reporting run dev` (Vite).
Managed workflows provide the ports and frontend base path. API docs: `/api/docs`.
Python dependencies are tracked in `pyproject.toml` / `uv.lock`; JavaScript dependencies
are tracked in the pnpm workspace lockfile.

## Data model

SQLite lives at `artifacts/api-server/finance/data/finance.sqlite3`. It is created and
seeded automatically if missing; existing data and commentary are not overwritten.

- `business_units`: Corporate, Operations, Sales & Marketing, Technology.
- `cost_centres`: 12 cost centres, three per business unit.
- `accounts`: the ten requested P&L accounts.
- `ledger`: whole-dollar USD by year, month, scenario, cost centre and account.
  Views `budget`, `actuals`, `latest_forecast`, `prior_year_actuals` expose each scenario.
- `kpis`: period-end headcount and customer count. Financial KPIs are derived from the ledger.
- `drivers`: explicitly seeded operational explanations and timing/run-rate/one-time classifications.
- `commentary`: persisted sentences with source references, audience, report context, review status and timestamps.
- `settings`: percentage/dollar materiality and audience.

2026 budget and forecast and 2025 prior-year actuals cover January–December.
2026 actuals cover January–September only. October–December reports explicitly show
unavailable actuals, not zero results. Financial YTD sums January to the selected
month. Headcount/customer YTD are closing balances, gross margin/OpEx ratios use
aggregated financials, and revenue/FTE uses cumulative revenue / average headcount.
Trend arrows compare the previous month (January compares December 2025).

The sample includes persistent Technology contractor costs from April, a September
Marketing campaign brought forward from October, September Corporate restructuring
fees, and revenue slightly below plan. Unknown causes are labeled unconfirmed.
Both strict thresholds must be exceeded: >5% AND >$50,000 by default.
Favourability treats revenue/profit increases as positive and expense increases as negative.
BU summaries describe operating expenses, not net profit.

## Commentary and AI

No key is required. In template mode the app constructs sentences from queried facts.
To enable OpenAI, add `OPENAI_API_KEY` through Replit Secrets and restart the API.
The key is only read server-side and is never included in browser code or logs.
The backend uses `gpt-4o-mini`.

For stronger numeric guarantees, OpenAI selects/orders **fact IDs** from an existing
database-derived sentence bank; it cannot author arbitrary numbers or explanations.
Every generated sentence carries source references to ledger records and documented
scenario notes. Invalid model output or API errors visibly fall back to template mode.
Chat supports financial summaries, named business units, material variances, and KPIs;
it is not an unrestricted question-answering system.

Generate creates missing drafts without overwriting existing edits or approvals.
Edits preserve source references; numeric tokens must already occur in the linked
sentences. Save changed text as Draft, then mark Reviewed, then Approved. Human
narrative edits still require finance-team review; source references are not an
independent verification of user-entered prose.

PDF and Word packs include financial tables, executive/BU/variance commentary with
review statuses, a KPI scorecard, revenue/OpEx trend charts and a monthly operating
profit bridge. Missing commentary sections are explicitly unsaved template drafts.
Exports are generated in memory, not persisted on disk. Source references link to
an appendix of ledger aggregates.

## Reseeding

Stop the API first and back up the SQLite file. **Deleting it removes all commentary
and settings as well as sample data.** To reset intentionally:

```sh
rm artifacts/api-server/finance/data/finance.sqlite3
```

Restart the API workflow; it recreates the deterministic dataset.

## Scope and publishing

This is a single shared demonstration workspace, without authentication or role-based
access control. Do not load confidential finance data or expose it publicly as an
internal production system without adding access controls.
SQLite persistence is local to the running server; for a durable multi-user hosted
deployment, provision persistent storage and backups before relying on review history.
The application deliberately retains the requested SQLite stack.
