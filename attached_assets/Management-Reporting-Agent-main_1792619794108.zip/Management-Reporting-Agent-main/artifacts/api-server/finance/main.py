import io
import json
import logging
from contextlib import asynccontextmanager
from typing import Literal
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from .data import connect, seed, settings
from .reporting import report, source_detail
from .commentary import generate, update, chat

logging.basicConfig(level=logging.INFO)


@asynccontextmanager
async def lifespan(app):
    seed()
    yield


app = FastAPI(title="Management Reporting Agent", lifespan=lifespan, docs_url="/api/docs", openapi_url="/api/openapi.json")
View = Literal["month", "ytd"]
Comparison = Literal["budget", "forecast", "prior"]
Audience = Literal["CFO", "Executive Leadership Team", "Business Unit Leader"]


class Settings(BaseModel):
    percentThreshold: float = Field(ge=0, le=100)
    amountThreshold: float = Field(ge=0, le=100000000)
    audience: Audience


class ReportInput(BaseModel):
    month: int = Field(ge=1, le=12)
    view: View
    comparison: Comparison
    audience: Audience


class Sentence(BaseModel):
    text: str = Field(min_length=1, max_length=5000)
    sourceIds: list[str] = Field(min_length=1, max_length=10)


class CommentaryInput(BaseModel):
    sentences: list[Sentence] = Field(min_length=1, max_length=20)
    status: Literal["Draft", "Reviewed", "Approved"]


class ChatInput(ReportInput):
    message: str = Field(min_length=1, max_length=4000)


@app.get("/api/healthz")
def health():
    return {"status": "ok"}


@app.get("/api/report")
def get_report(month: int = Query(9, ge=1, le=12), view: View = "month", comparison: Comparison = "budget"):
    return report(month, view, comparison)


@app.get("/api/settings")
def get_settings():
    return settings()


@app.put("/api/settings")
def save_settings(body: Settings):
    with connect() as db:
        db.execute("UPDATE settings SET payload=? WHERE id=1", (json.dumps(body.model_dump()),))
    return body


@app.post("/api/commentary/generate")
def generate_commentary(body: ReportInput):
    try:
        return generate(**body.model_dump())
    except ValueError as exc:
        raise HTTPException(400, str(exc))


@app.patch("/api/commentary/{cid}")
def update_commentary(cid: int, body: CommentaryInput):
    try:
        return update(cid, body.model_dump())
    except LookupError as exc:
        raise HTTPException(404, str(exc))
    except ValueError as exc:
        raise HTTPException(400, str(exc))


@app.post("/api/chat")
def ask_assistant(body: ChatInput):
    return chat(body.model_dump())


@app.get("/api/sources/{sid}")
def get_source(sid: str):
    try:
        return source_detail(sid)
    except ValueError as exc:
        raise HTTPException(400, str(exc))


@app.get("/api/export/{format}")
def export_pack(format: Literal["pdf", "docx"], month: int = Query(9, ge=1, le=12),
                view: View = "month", comparison: Comparison = "budget"):
    from .exports import make_pack
    data = report(month, view, comparison)
    if not data["available"]:
        raise HTTPException(400, "Cannot export: actuals are not loaded for this period.")
    content = make_pack(data, format)
    mime = "application/pdf" if format == "pdf" else "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    return StreamingResponse(io.BytesIO(content), media_type=mime,
                             headers={"Content-Disposition": f'attachment; filename="Management-Pack-2026-{month:02d}-{view}.{format}"'})
