"""Grounded generation: the LLM selects fact IDs, never supplies financial prose."""
import json
import logging
import os
import re
from datetime import datetime, timezone
from .data import BUS, ACCOUNTS, connect, month_name
from .reporting import report, financial_row, drivers, commentary_dict, source_context

log = logging.getLogger("finance")


def sentence(text, *sources):
    return dict(text=text, sourceIds=list(sources))


def amount(value):
    return f"${abs(value):,.0f}"


def row_sentence(row, comparison, prefix=""):
    direction = "above" if row["variance"] >= 0 else "below"
    label = {"prior": "prior year", "forecast": "latest forecast", "budget": "budget"}[comparison]
    return sentence(f'{prefix}{row["name"]} was {amount(row["actual"])}, {amount(row["variance"])} '
                    f'({abs(row["variancePercent"]):.2f}%) {direction} {label} of {amount(row["comparator"])}'
                    f' — {"favourable" if row["favourable"] else "unfavourable"}.', row["sourceId"])


def blocks(data, audience):
    m, view, comparison = data["month"], data["view"], data["comparison"]
    intro = {"CFO": "Group performance: ", "Executive Leadership Team": "Leadership overview: ",
             "Business Unit Leader": "Budget-owner overview: "}[audience]
    period = f'{month_name(m)} 2026 {"YTD" if view == "ytd" else "month"}'
    pnl = {r["name"]: r for r in data["pnl"]}
    summary = [row_sentence(pnl[name], comparison, f"{intro if i == 0 else ''}{period}: ")
               for i, name in enumerate(["Revenue", "Operating Profit", "Operating Expenses"])]
    if data["variances"]:
        top = data["variances"][0]
        summary.append(sentence(f'The largest material variance is {top["businessUnit"]} / {top["account"]} '
                                f'at {amount(top["variance"])} ({top["classification"].lower()}); {top["driver"]}', top["sourceId"]))
    result = [dict(section="executive", title="Executive summary", sentences=summary)]
    for b, unit in enumerate(data["businessUnits"]):
        sentences = [row_sentence(unit, comparison, f'{period}: ')]
        # Explain the largest BU account variance even when below materiality.
        rows = [financial_row(m, view, comparison, a, b) for a in range(2, 10)]
        top = max(rows, key=lambda r: abs(r["variance"]))
        a = ACCOUNTS.index(top["name"])
        classification, driver = drivers(m, view, b, a)
        sentences.extend([row_sentence(top, comparison), sentence(f"{classification}: {driver}", top["sourceId"])])
        result.append(dict(section=f"bu:{b}", title=BUS[b], sentences=sentences))
    for row in data["variances"]:
        result.append(dict(section=f'variance:{row["id"]}', title=f'{row["businessUnit"]} · {row["account"]}',
                           sentences=[row_sentence(row, comparison),
                                      sentence(f'{row["classification"]}: {row["driver"]}', row["sourceId"])]))
    return result


def select_facts(candidates, prompt, max_count=None):
    """Only allow the model to select/reorder exact server-authored source facts."""
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        return candidates[:max_count] if max_count else candidates, "Template mode"
    try:
        from openai import OpenAI
        client = OpenAI(api_key=key, timeout=25, max_retries=1)
        result = client.chat.completions.create(
            model="gpt-4o-mini", response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": "You are a finance editor. Select and order the supplied fact IDs to answer the request. "
                 "Return only JSON {\"ids\":[integer,...]}. Never invent facts. Preserve source facts verbatim. "
                 f"Select at most {max_count or len(candidates)} facts."},
                {"role": "user", "content": json.dumps({"request": prompt, "facts": [{"id": i, "text": s["text"]} for i, s in enumerate(candidates)]})},
            ])
        ids = json.loads(result.choices[0].message.content)["ids"]
        if not isinstance(ids, list) or not ids or any(type(i) is not int or not 0 <= i < len(candidates) for i in ids):
            raise ValueError("Invalid fact selection")
        ids = list(dict.fromkeys(ids))
        return [candidates[i] for i in ids[:max_count or len(ids)]], "OpenAI · source-locked"
    except Exception:
        log.warning("OpenAI fact selection unavailable; using source-linked templates")
        return candidates[:max_count] if max_count else candidates, "Template mode · AI unavailable"


def generate(month, view, comparison, audience):
    data = report(month, view, comparison)
    if not data["available"]:
        raise ValueError("Actuals are only available through September 2026.")
    items = blocks(data, audience)
    # LLM chooses ordering only; full required statement coverage is preserved.
    executive = items[0]["sentences"]
    selected, engine = select_facts(executive, f"Order all facts for {audience} monthly commentary.")
    if len(selected) == len(executive):
        items[0]["sentences"] = selected
    now = datetime.now(timezone.utc).isoformat()
    with connect() as db:
        for item in items:
            db.execute("""INSERT INTO commentary(month,view,comparison,section,title,status,audience,sentences,engine,updated_at)
            VALUES(?,?,?,?,?,'Draft',?,?,?,?) ON CONFLICT(month,view,comparison,section,audience) DO NOTHING""",
                       (month, view, comparison, item["section"], item["title"], audience, json.dumps(item["sentences"]), engine, now))
        rows = db.execute("SELECT * FROM commentary WHERE month=? AND view=? AND comparison=? AND audience=? ORDER BY id",
                          (month, view, comparison, audience)).fetchall()
    return [commentary_dict(r) for r in rows]


def numeric_tokens(text):
    # Exact tokens rather than floating-point equality prevent changing scales/signs.
    return set(re.findall(r"(?<!\w)[+-]?\$?\d[\d,]*(?:\.\d+)?%?", text))


def update(cid, payload):
    with connect() as db:
        row = db.execute("SELECT * FROM commentary WHERE id=?", (cid,)).fetchone()
        if not row:
            raise LookupError("Commentary not found")
        original = json.loads(row["sentences"])
        valid_sources = {s for item in original for s in item["sourceIds"]}
        by_source = {s: set() for s in valid_sources}
        for item in original:
            for sid in item["sourceIds"]:
                by_source[sid].update(numeric_tokens(item["text"]))
        for item in payload["sentences"]:
            if not item["text"].strip() or not item["sourceIds"] or not set(item["sourceIds"]) <= valid_sources:
                raise ValueError("Every sentence must retain a valid source reference from this commentary.")
            allowed = set().union(*(by_source[s] for s in item["sourceIds"]))
            if not numeric_tokens(item["text"]) <= allowed:
                raise ValueError("New or changed numbers are not allowed. Keep the source-linked figures unchanged.")
        changed = payload["sentences"] != original
        if changed and payload["status"] != "Draft":
            raise ValueError("Save edited text as Draft first, then review and approve it.")
        statuses = ["Draft", "Reviewed", "Approved"]
        if statuses.index(payload["status"]) > statuses.index(row["status"]) + 1:
            raise ValueError("Review commentary before approving it.")
        db.execute("UPDATE commentary SET sentences=?,status=?,engine=?,updated_at=? WHERE id=?",
                   (json.dumps(payload["sentences"]), payload["status"], "Human edited · source-linked" if changed else row["engine"],
                    datetime.now(timezone.utc).isoformat(), cid))
        return commentary_dict(db.execute("SELECT * FROM commentary WHERE id=?", (cid,)).fetchone())


def chat(payload):
    message = payload["message"]
    text = message.lower()
    m, view, comparison = payload["month"], payload["view"], payload["comparison"]
    for month in range(1, 13):
        if month_name(month).lower() in text:
            m = month
    if "ytd" in text or "year to date" in text:
        view = "ytd"
    elif "monthly" in text or "month" in text:
        view = "month"
    if "budget" in text or "plan" in text:
        comparison = "budget"
    elif "forecast" in text:
        comparison = "forecast"
    elif "prior year" in text:
        comparison = "prior"
    data = report(m, view, comparison)
    if not data["available"]:
        return dict(sentences=[sentence(data["dataNote"])], engine="Template mode")
    candidates = blocks(data, payload["audience"])
    bu = next((i for i, name in enumerate(BUS) if name.lower() in text or (i == 2 and "marketing" in text)), None)
    if bu is not None:
        facts = next(b["sentences"] for b in candidates if b["section"] == f"bu:{bu}")
    elif "variance" in text:
        relevant = [v for v in data["variances"] if not v["favourable"]] if "unfavourable" in text else data["variances"]
        facts = []
        for v in relevant:
            facts += [row_sentence(v, comparison, f'{v["businessUnit"]}: '),
                      sentence(f'{v["classification"]}: {v["driver"]}', v["sourceId"])]
        if not facts:
            facts = [sentence("No variances exceed both configured materiality thresholds.", data["pnl"][0]["sourceId"])]
    elif any(word in text for word in ["kpi", "headcount", "margin", "fte", "customer"]):
        facts = [sentence(k["explanation"], k["sourceId"]) for k in data["kpis"]]
    elif any(word in text for word in ["summary", "summar", "performance", "commentary", "revenue", "profit", "opex"]):
        facts = candidates[0]["sentences"]
    else:
        return dict(sentences=[sentence("I can explain financial performance, business-unit costs, material variances and KPIs. Ask about a month in January–September 2026; I do not have external or operational records beyond this sample dataset.")], engine="Template mode")
    limit = 3 if "three" in text or "3 bullet" in text else min(len(facts), 6)
    selected, engine = select_facts(facts, f"{payload['audience']}: {message}", limit)
    return dict(sentences=selected, engine=engine)
