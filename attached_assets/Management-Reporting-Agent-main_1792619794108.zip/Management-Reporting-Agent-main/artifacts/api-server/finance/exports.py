"""In-memory PDF/Word packs. No generated files are stored on disk."""
import io
from html import escape
from PIL import Image, ImageDraw, ImageFont
from .commentary import blocks
from .reporting import source_context, totals, financial_row
from .data import ACCOUNTS

NAVY = "#132d4c"
BLUE = "#2975bd"
GREEN = "#248374"
RED = "#bb4b54"


def money(n):
    return f"-${abs(n):,.0f}" if n < 0 else f"${n:,.0f}"


def chart_image(data, metric):
    image = Image.new("RGB", (1100, 410), "white")
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default(size=17)
    small = ImageFont.load_default(size=14)
    draw.text((50, 12), f"Monthly {metric.title()} vs Budget and Prior Year (USD millions)", fill=NAVY, font=font)
    series = [(metric, "Actual", BLUE), (metric + "Budget", "Budget", "#7f8fa5"), (metric + "Prior", "Prior year", GREEN)]
    maximum = max(p[key] or 0 for p in data["trends"] for key, _, _ in series) * 1.12
    for j in range(5):
        y = 330 - j * 65
        draw.line((80, y, 1060, y), fill="#e4eaf0")
        draw.text((5, y - 8), f"{maximum * j / 4 / 1e6:.1f}", fill="#627387", font=small)
    for key, label, color in series:
        points = []
        for i, p in enumerate(data["trends"]):
            if p[key] is None:
                continue
            points.append((80 + i * 88, 330 - p[key] / maximum * 260))
        if len(points) > 1:
            draw.line(points, fill=color, width=4)
        for x, y in points:
            draw.ellipse((x-3, y-3, x+3, y+3), fill=color)
    for i, p in enumerate(data["trends"]):
        draw.text((70 + i * 88, 340), p["month"], fill="#627387", font=small)
    for i, (_, label, color) in enumerate(series):
        draw.line((320 + i*170, 385, 345 + i*170, 385), fill=color, width=4)
        draw.text((353 + i*170, 376), label, fill=NAVY, font=small)
    output = io.BytesIO()
    image.save(output, "PNG")
    return output.getvalue()


def bridge_image(data):
    # Budget-to-actual operating-profit bridge uses every account exactly once.
    m = data["month"]
    rows = [financial_row(m, "month", "budget", a) for a in range(10)]
    start = totals(m, "month", "profit")["budget"]
    steps = [(r["name"].split(" ")[0], r["variance"] * (1 if i == 0 else -1)) for i, r in enumerate(rows)]
    end = start + sum(v for _, v in steps)
    bars = [("Budget", 0, start, NAVY)]
    current = start
    for label, delta in steps:
        bars.append((label, current, current + delta, GREEN if delta >= 0 else RED))
        current += delta
    bars.append(("Actual", 0, end, NAVY))
    maximum = max(max(a, b) for _, a, b, _ in bars) * 1.2
    minimum = min(0, min(min(a, b) for _, a, b, _ in bars)) * 1.1
    image = Image.new("RGB", (1100, 410), "white")
    draw = ImageDraw.Draw(image)
    font, small = ImageFont.load_default(size=17), ImageFont.load_default(size=12)
    draw.text((45, 12), "Monthly operating profit bridge: budget to actual (USD millions)", fill=NAVY, font=font)
    y = lambda value: 325 - (value-minimum)/(maximum-minimum)*250
    draw.line((55, y(0), 1080, y(0)), fill="#bac5d0")
    for i, (label, a, b, color) in enumerate(bars):
        x = 60 + i*85
        draw.rectangle((x, min(y(a), y(b)), x+53, max(y(a), y(b))+1), fill=color)
        value = b if i in [0, len(bars)-1] else b-a
        draw.text((x-3, min(y(a), y(b))-20), f"{value/1e6:+.2f}" if i not in [0,len(bars)-1] else f"{value/1e6:.2f}", fill=NAVY, font=small)
        draw.text((x-7, 345), label[:12], fill=NAVY, font=small)
        if i < len(bars)-1:
            draw.line((x+53, y(b), x+85, y(b)), fill="#bac5d0")
    output = io.BytesIO()
    image.save(output, "PNG")
    return output.getvalue()


def make_pack(data, format):
    # Fill only missing sections with clearly marked unsaved drafts.
    existing = {c["section"]: c for c in data["commentary"]}
    sections = []
    for block in blocks(data, data["settings"]["audience"]):
        sections.append(existing.get(block["section"], {**block, "status": "Draft", "engine": "Template mode · unsaved"}))
    refs = {}
    for block in sections:
        for s in block["sentences"]:
            for sid in s["sourceIds"]:
                refs.setdefault(sid, f"S{len(refs)+1}")
    sources = []
    for sid, label in refs.items():
        m, view, account, bu, _ = source_context(sid)
        values = totals(m, view, account, bu)
        sources.append((label, f'{view.upper()} · {ACCOUNTS[account] if isinstance(account,int) else account} · '
                        f'BU {bu if bu >= 0 else "Group"}', values, sid))
    charts = [chart_image(data, "revenue"), chart_image(data, "opex"), bridge_image(data)]
    if format == "docx":
        return make_docx(data, sections, refs, sources, charts)
    return make_pdf(data, sections, refs, sources, charts)


def make_pdf(data, sections, refs, sources, charts):
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.enums import TA_LEFT
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
    output = io.BytesIO()
    doc = SimpleDocTemplate(output, pagesize=(595, 842), rightMargin=40, leftMargin=40, topMargin=40, bottomMargin=40)
    styles = getSampleStyleSheet()
    styles["BodyText"].fontSize = 9
    styles["BodyText"].leading = 14
    styles["Heading1"].textColor = colors.HexColor(NAVY)
    elements = []
    def p(text, style="BodyText"):
        elements.append(Paragraph(text, styles[style]))
        elements.append(Spacer(1, 7))
    def table(rows, widths=None):
        cells = [[Paragraph(escape(str(c)), styles["BodyText"]) for c in row] for row in rows]
        t = Table(cells, colWidths=widths, repeatRows=1, hAlign="LEFT")
        t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#e4edf5")),
                               ("VALIGN",(0,0),(-1,-1),"TOP"),("BOTTOMPADDING",(0,0),(-1,-1),7),
                               ("LINEBELOW",(0,0),(-1,-1),.3,colors.HexColor("#dae1e8"))]))
        elements.extend([t, Spacer(1, 16)])
    p("Management Reporting Agent", "Title")
    p(f'{data["periodLabel"]} · {data["view"].upper()} · vs {data["comparison"]}', "Heading1")
    p("ILLUSTRATIVE SAMPLE DATA — Internal management reporting. Commentary status is shown per section.")
    p(f'Materiality: greater than {data["settings"]["percentThreshold"]}% AND {money(data["settings"]["amountThreshold"])}. Audience: {data["settings"]["audience"]}.')
    def section(block):
        p(escape(block["title"]), "Heading2")
        p(escape(f'{block["status"]} · {block["engine"]}'))
        for s in block["sentences"]:
            links = " ".join(f'<link href="#{refs[sid]}" color="#2975bd">[{refs[sid]}]</link>' for sid in s["sourceIds"])
            p(escape(s["text"]) + " " + links)
    section(sections[0])
    p("P&amp;L summary (USD)", "Heading2")
    table([["Account", "Actual", data["comparison"].title(), "Variance", "F / U"]] +
          [[r["name"],money(r["actual"]),money(r["comparator"]),money(r["variance"]), "F" if r["favourable"] else "U"] for r in data["pnl"]],
          [157,105,105,105,43])
    for block in sections[1:]:
        section(block)
    elements.append(PageBreak())
    p("KPI scorecard", "Heading1")
    table([["KPI", "Month", "YTD", "Budget", "Prior year"]] +
          [[k["name"], *[f'{k[x]:,.2f}{k["unit"] if k["unit"] == "%" else ""}' for x in ["current","ytd","budget","prior"]]] for k in data["kpis"]],
          [155,90,90,90,90])
    for k in data["kpis"]:
        p(escape(k["explanation"]))
    for chart in charts:
        elements.append(Image(io.BytesIO(chart), width=515, height=192))
        elements.append(Spacer(1, 12))
    elements.append(PageBreak())
    p("Source figures", "Heading1")
    p("All figures below are reproducible ledger aggregates. Expenses are positive; profit subtracts expenses. Commentary references link here. Drivers are seeded scenario notes, not independently verified operational facts.")
    for label, description, values, sid in sources:
        p(f'<a name="{label}"/><b>{label} — {escape(description)}</b>')
        p(" · ".join(f"{key.title()}: {money(value)}" for key,value in values.items()))
    def footer(canvas, doc):
        canvas.setFont("Helvetica", 8)
        canvas.drawString(40, 22, "Management Reporting Agent · Sample data")
        canvas.drawRightString(555, 22, str(doc.page))
    doc.build(elements, onFirstPage=footer, onLaterPages=footer)
    return output.getvalue()


def make_docx(data, sections, refs, sources, charts):
    from docx import Document
    from docx.shared import Inches, Pt
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    doc = Document()
    doc.styles["Normal"].font.name = "Calibri"
    doc.styles["Normal"].font.size = Pt(10)
    doc.add_heading("Management Reporting Agent", 0)
    doc.add_heading(f'{data["periodLabel"]} · {data["view"].upper()} · vs {data["comparison"]}', 1)
    doc.add_paragraph("ILLUSTRATIVE SAMPLE DATA — Internal management reporting. Draft content requires review.")
    doc.add_paragraph(f'Audience: {data["settings"]["audience"]}. Materiality: >{data["settings"]["percentThreshold"]}% AND >{money(data["settings"]["amountThreshold"])}.')
    def section(block):
        doc.add_heading(block["title"], 2)
        doc.add_paragraph(f'{block["status"]} · {block["engine"]}')
        for s in block["sentences"]:
            p = doc.add_paragraph(s["text"] + " ")
            for sid in s["sourceIds"]:
                link = OxmlElement("w:hyperlink")
                link.set(qn("w:anchor"), refs[sid])
                run, text = OxmlElement("w:r"), OxmlElement("w:t")
                text.text = f'[{refs[sid]}] '
                run.append(text)
                link.append(run)
                p._p.append(link)
    def table(rows):
        t = doc.add_table(rows=1, cols=len(rows[0]))
        t.style = "Light Shading Accent 1"
        for i, cell in enumerate(rows[0]):
            t.rows[0].cells[i].text = str(cell)
        for row in rows[1:]:
            cells = t.add_row().cells
            for i, value in enumerate(row):
                cells[i].text = str(value)
    section(sections[0])
    doc.add_heading("P&L summary (USD)", 2)
    table([["Account","Actual",data["comparison"].title(),"Variance","F/U"]] +
          [[r["name"],money(r["actual"]),money(r["comparator"]),money(r["variance"]), "F" if r["favourable"] else "U"] for r in data["pnl"]])
    for block in sections[1:]:
        section(block)
    doc.add_heading("KPI scorecard", 1)
    table([["KPI","Month","YTD","Budget","Prior year"]] +
          [[k["name"], *[f'{k[x]:,.2f}{k["unit"] if k["unit"] == "%" else ""}' for x in ["current","ytd","budget","prior"]]] for k in data["kpis"]])
    for k in data["kpis"]:
        doc.add_paragraph(k["explanation"])
    for chart in charts:
        doc.add_picture(io.BytesIO(chart), width=Inches(6.3))
    doc.add_heading("Source figures", 1)
    doc.add_paragraph("Reproducible ledger aggregates. Expenses are positive; profit subtracts expenses. Drivers are seeded scenario notes.")
    for i, (label, description, values, sid) in enumerate(sources):
        p = doc.add_paragraph(f"{label} — {description}")
        bookmark = OxmlElement("w:bookmarkStart")
        bookmark.set(qn("w:id"), str(i))
        bookmark.set(qn("w:name"), label)
        p._p.insert(0, bookmark)
        end = OxmlElement("w:bookmarkEnd")
        end.set(qn("w:id"), str(i))
        p._p.append(end)
        doc.add_paragraph(" · ".join(f"{key.title()}: {money(value)}" for key, value in values.items()))
    output = io.BytesIO()
    doc.save(output)
    return output.getvalue()
