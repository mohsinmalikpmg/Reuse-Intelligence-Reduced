"""Management Reporting Agent backend."""
