import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useGetReport, type GetReportComparison, type GetReportView } from "@workspace/api-client-react";

export const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
export const MONTHS_LONG = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
export const COMPARISON_LABEL: Record<string, string> = { budget: "Budget", forecast: "Forecast", prior: "Prior year" };

type Period = {
  month: number;
  view: GetReportView;
  comparison: GetReportComparison;
  setMonth: (m: number) => void;
  setView: (v: GetReportView) => void;
  setComparison: (c: GetReportComparison) => void;
  sourceId: string | null;
  openSource: (id: string | null) => void;
};

const Ctx = createContext<Period | null>(null);

function load() {
  try {
    const raw = localStorage.getItem("mra-period");
    if (raw) return JSON.parse(raw) as { month: number; view: GetReportView; comparison: GetReportComparison };
  } catch {
    /* ignore */
  }
  return { month: 9, view: "month" as GetReportView, comparison: "budget" as GetReportComparison };
}

export function PeriodProvider({ children }: { children: ReactNode }) {
  const init = useMemo(load, []);
  const [month, setMonth] = useState(init.month);
  const [view, setView] = useState<GetReportView>(init.view);
  const [comparison, setComparison] = useState<GetReportComparison>(init.comparison);
  const [sourceId, openSource] = useState<string | null>(null);
  useEffect(() => {
    localStorage.setItem("mra-period", JSON.stringify({ month, view, comparison }));
  }, [month, view, comparison]);
  return (
    <Ctx.Provider value={{ month, view, comparison, setMonth, setView, setComparison, sourceId, openSource }}>
      {children}
    </Ctx.Provider>
  );
}

export function usePeriod() {
  const c = useContext(Ctx);
  if (!c) throw new Error("PeriodProvider missing");
  return c;
}

export function useReport() {
  const { month, view, comparison } = usePeriod();
  return useGetReport({ month, view, comparison });
}

export function money(v: number | null | undefined, opts: { compact?: boolean; sign?: boolean } = {}) {
  if (v === null || v === undefined || Number.isNaN(v)) return "—";
  const abs = Math.abs(v);
  let s: string;
  if (opts.compact) {
    if (abs >= 1e6) s = `$${(abs / 1e6).toFixed(abs >= 1e7 ? 1 : 2)}M`;
    else if (abs >= 1e3) s = `$${(abs / 1e3).toFixed(0)}K`;
    else s = `$${abs.toFixed(0)}`;
  } else {
    s = `$${Math.round(abs).toLocaleString("en-US")}`;
  }
  if (v < 0) return opts.sign ? `-${s}` : `(${s})`;
  return opts.sign && v > 0 ? `+${s}` : s;
}

export function pct(v: number | null | undefined, sign = true) {
  if (v === null || v === undefined || !Number.isFinite(v)) return "—";
  return `${sign && v > 0 ? "+" : ""}${v.toFixed(1)}%`;
}

export function kpiValue(v: number, unit: string) {
  const u = unit.toLowerCase();
  if (u === "$" || u === "usd") return money(v, { compact: Math.abs(v) >= 1e5 });
  if (u === "%") return `${v.toFixed(1)}%`;
  if (u === "days" || u === "x") return `${v.toFixed(1)}${u === "x" ? "x" : " days"}`;
  return `${v.toLocaleString("en-US", { maximumFractionDigits: 1 })}${unit && unit !== "number" ? ` ${unit}` : ""}`;
}

export function errMsg(e: unknown) {
  if (!e) return "Unknown error";
  const anyE = e as { message?: string; data?: { error?: string; message?: string; detail?: unknown } };
  return anyE.data?.error ?? anyE.data?.message ?? (typeof anyE.data?.detail === "string" ? anyE.data.detail : undefined) ?? anyE.message ?? "Request failed";
}
