import { useState } from "react";
import { getExportPackUrl } from "@workspace/api-client-react";
import { Download, FileText, FileType2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useReport, usePeriod, COMPARISON_LABEL, MONTHS_LONG } from "@/lib/period";
import { ErrorBlock, LoadingBlock, PageHeader, UnavailableBlock } from "@/components/states";
import { StatusPill } from "@/components/commentary-editor";

export default function Packs() {
  const q = useReport();
  const { month, view, comparison } = usePeriod();
  const { toast } = useToast();
  const [busy, setBusy] = useState<"pdf" | "docx" | null>(null);
  const r = q.data;

  const download = async (format: "pdf" | "docx") => {
    setBusy(format);
    try {
      const params = new URLSearchParams({ month: String(month), view, comparison });
      const res = await fetch(`${getExportPackUrl(format)}?${params}`, { credentials: "include" });
      if (!res.ok) throw new Error(`Export failed (${res.status}) ${await res.text().catch(() => "")}`.trim());
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `management-pack-2026-${String(month).padStart(2, "0")}-${view}-${comparison}.${format}`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      toast({ title: `${format.toUpperCase()} pack downloaded`, description: `${MONTHS_LONG[month - 1]} 2026` });
    } catch (e) {
      toast({ title: "Export failed", description: e instanceof Error ? e.message : "Unknown error", variant: "destructive" });
    } finally {
      setBusy(null);
    }
  };

  const approved = r?.commentary.filter((c) => c.status === "Approved").length ?? 0;
  return (
    <>
      <PageHeader eyebrow="Distribution" title="Monthly packs" />
      {q.isLoading && <LoadingBlock rows={3} />}
      {q.isError && <ErrorBlock error={q.error} onRetry={() => q.refetch()} />}
      {r && !r.available && <UnavailableBlock note={r.dataNote} />}
      {r && r.available && (
        <div className="grid lg:grid-cols-[minmax(0,1fr)_340px] gap-5 items-start">
          <div className="bg-card border rounded-md">
            <div className="px-5 py-4 border-b">
              <div className="eyebrow">Pack contents</div>
              <h2 className="font-serif text-xl font-semibold mt-1">{r.periodLabel} · {view === "ytd" ? "YTD" : "Month"} vs {COMPARISON_LABEL[comparison]}</h2>
            </div>
            <ol className="divide-y text-[13px]">
              {[["Profit and loss", `${r.pnl.length} lines`], ["Business unit summary", `${r.businessUnits.length} units`], ["Material variances", `${r.variances.length} items`], ["KPI scorecard", `${r.kpis.length} measures`], ["Revenue and OpEx trend", `${r.trends.length} months`]].map(([a, b], i) => (
                <li key={a} className="px-5 py-2.5 flex justify-between"><span><span className="num text-muted-foreground mr-3">{String(i + 1).padStart(2, "0")}</span>{a}</span><span className="text-muted-foreground">{b}</span></li>
              ))}
              {r.commentary.map((c, i) => (
                <li key={c.id} className="px-5 py-2.5 flex justify-between items-center"><span><span className="num text-muted-foreground mr-3">{String(i + 6).padStart(2, "0")}</span>Commentary: {c.title}</span><StatusPill status={c.status} /></li>
              ))}
            </ol>
          </div>
          <div className="space-y-3">
            {approved < r.commentary.length && (
              <div className="text-[12px] border border-amber-300 bg-amber-50 text-amber-900 rounded-md px-3 py-2" data-testid="text-pack-warning">
                {r.commentary.length - approved} of {r.commentary.length} commentary sections are not yet approved. They will be exported with their current status.
              </div>
            )}
            {[["pdf", "PDF board pack", "Fixed layout for circulation", FileText], ["docx", "Word document", "Editable for final tailoring", FileType2]].map(([f, t, d, Icon]) => {
              const fmt = f as "pdf" | "docx";
              const I = Icon as typeof FileText;
              return (
                <div key={fmt} className="bg-card border rounded-md p-4 flex items-center gap-3">
                  <div className="h-10 w-10 rounded-sm bg-accent grid place-items-center"><I className="h-5 w-5 text-primary" /></div>
                  <div className="flex-1"><div className="font-medium text-sm">{t as string}</div><div className="text-xs text-muted-foreground">{d as string}</div></div>
                  <Button size="sm" disabled={!!busy} onClick={() => download(fmt)} data-testid={`button-export-${fmt}`}>
                    {busy === fmt ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Download className="h-3.5 w-3.5" />}
                  </Button>
                </div>
              );
            })}
            <p className="text-[11px] text-muted-foreground">Packs are generated from seeded sample data and labelled as such.</p>
          </div>
        </div>
      )}
    </>
  );
}
