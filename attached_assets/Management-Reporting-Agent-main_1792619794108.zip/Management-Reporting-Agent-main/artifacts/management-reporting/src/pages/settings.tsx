import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useGetSettings, useSaveSettings, getGetSettingsQueryKey, getGetReportQueryKey, SettingsAudience, type Settings } from "@workspace/api-client-react";
import { Check, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { ErrorBlock, LoadingBlock, PageHeader } from "@/components/states";
import { errMsg } from "@/lib/period";
import { cn } from "@/lib/utils";

export default function SettingsPage() {
  const q = useGetSettings();
  const save = useSaveSettings();
  const qc = useQueryClient();
  const { toast } = useToast();
  const [form, setForm] = useState<Settings | null>(null);
  const [savedAt, setSavedAt] = useState(0);
  useEffect(() => {
    if (q.data && !form) setForm(q.data);
  }, [q.data, form]);
  const pctOk = form ? form.percentThreshold >= 0 && form.percentThreshold <= 100 : false;
  const amtOk = form ? form.amountThreshold >= 0 && form.amountThreshold <= 100000000 : false;
  const dirty = form && q.data && JSON.stringify(form) !== JSON.stringify(q.data);

  const submit = () => {
    if (!form || !pctOk || !amtOk) return;
    save.mutate({ data: form }, {
      onSuccess: (s) => {
        qc.setQueryData(getGetSettingsQueryKey(), s);
        qc.invalidateQueries({ queryKey: [getGetReportQueryKey()[0]] });
        setForm(s);
        setSavedAt(Date.now());
        toast({ title: "Settings saved", description: "Materiality applied to all reports." });
      },
      onError: (e) => toast({ title: "Save failed", description: errMsg(e), variant: "destructive" }),
    });
  };

  return (
    <>
      <PageHeader eyebrow="Configuration" title="Settings" />
      {q.isLoading && <LoadingBlock rows={3} />}
      {q.isError && <ErrorBlock error={q.error} onRetry={() => q.refetch()} />}
      {form && (
        <div className="max-w-2xl bg-card border rounded-md divide-y">
          <section className="p-5">
            <h2 className="font-serif text-lg font-semibold">Materiality thresholds</h2>
            <p className="text-sm text-muted-foreground mt-0.5">A variance is material when it breaches either threshold.</p>
            <div className="grid sm:grid-cols-2 gap-4 mt-4">
              <div>
                <Label htmlFor="pct" className="text-xs">Percentage threshold (%)</Label>
                <Input id="pct" type="number" step="0.1" min={0} max={100} value={form.percentThreshold} onChange={(e) => setForm({ ...form, percentThreshold: Number(e.target.value) })} className={cn("mt-1 num", !pctOk && "border-destructive")} data-testid="input-percent-threshold" />
                {!pctOk && <p className="text-xs text-destructive mt-1">Must be between 0 and 100.</p>}
              </div>
              <div>
                <Label htmlFor="amt" className="text-xs">Amount threshold (USD)</Label>
                <Input id="amt" type="number" step="1000" min={0} value={form.amountThreshold} onChange={(e) => setForm({ ...form, amountThreshold: Number(e.target.value) })} className={cn("mt-1 num", !amtOk && "border-destructive")} data-testid="input-amount-threshold" />
                {!amtOk && <p className="text-xs text-destructive mt-1">Must be between 0 and 100,000,000.</p>}
              </div>
            </div>
          </section>
          <section className="p-5">
            <h2 className="font-serif text-lg font-semibold">Default audience</h2>
            <p className="text-sm text-muted-foreground mt-0.5">Sets tone and depth for generated commentary and assistant answers.</p>
            <div className="grid sm:grid-cols-3 gap-2 mt-4">
              {Object.values(SettingsAudience).map((a) => (
                <button key={a} type="button" onClick={() => setForm({ ...form, audience: a })} data-testid={`option-audience-${a.replace(/\s/g, "-").toLowerCase()}`}
                  className={cn("text-left border rounded-md px-3 py-2.5 text-sm transition-colors", form.audience === a ? "border-primary bg-accent font-medium" : "hover:bg-muted")}>
                  {a}
                </button>
              ))}
            </div>
          </section>
          <div className="p-4 flex items-center justify-end gap-3 bg-muted/40">
            {savedAt > 0 && !dirty && <span key={savedAt} className="save-flash text-xs fav flex items-center gap-1"><Check className="h-3.5 w-3.5" />Saved</span>}
            {dirty && <span className="text-xs text-muted-foreground">Unsaved changes</span>}
            <Button variant="ghost" size="sm" disabled={!dirty} onClick={() => q.data && setForm(q.data)} data-testid="button-reset">Reset</Button>
            <Button size="sm" disabled={!dirty || !pctOk || !amtOk || save.isPending} onClick={submit} data-testid="button-save-settings">
              {save.isPending && <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" />}Save settings
            </Button>
          </div>
        </div>
      )}
    </>
  );
}
