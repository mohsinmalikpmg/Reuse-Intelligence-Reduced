import { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { useReport, money, pct, COMPARISON_LABEL, usePeriod } from "@/lib/period";
import { ErrorBlock, LoadingBlock, PageHeader, UnavailableBlock, EmptyBlock } from "@/components/states";
import { VarianceBridge } from "@/components/finance";
import { Cite } from "@/components/source-sheet";
import { cn } from "@/lib/utils";

export default function Variances() {
  const q = useReport();
  const { comparison } = usePeriod();
  const [search, setSearch] = useState("");
  const [adverseOnly, setAdverseOnly] = useState(false);
  const r = q.data;
  const rows = useMemo(() => {
    const list = r?.variances ?? [];
    return list
      .filter((v) => (!adverseOnly || !v.favourable) && `${v.name} ${v.businessUnit} ${v.account} ${v.driver}`.toLowerCase().includes(search.toLowerCase()))
      .sort((a, b) => Math.abs(b.variance) - Math.abs(a.variance));
  }, [r, search, adverseOnly]);
  const fav = rows.filter((v) => v.favourable).reduce((a, v) => a + Math.abs(v.variance), 0);
  const adv = rows.filter((v) => !v.favourable).reduce((a, v) => a + Math.abs(v.variance), 0);
  return (
    <>
      <PageHeader eyebrow={r ? `${r.periodLabel} vs ${COMPARISON_LABEL[comparison]}` : "Analysis"} title="Material variances" />
      {q.isLoading && <LoadingBlock />}
      {q.isError && <ErrorBlock error={q.error} onRetry={() => q.refetch()} />}
      {r && !r.available && <UnavailableBlock note={r.dataNote} />}
      {r && r.available && (
        <div className="space-y-5">
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-[12.5px] bg-card border rounded-md px-4 py-3">
            <span>Threshold: <b className="num">{r.settings.percentThreshold}%</b> or <b className="num">{money(r.settings.amountThreshold)}</b></span>
            <span>{rows.length} items</span>
            <span className="fav num">Favourable {money(fav, { compact: true })}</span>
            <span className="adv num">Adverse {money(adv, { compact: true })}</span>
            <div className="ml-auto flex items-center gap-3">
              <label className="flex items-center gap-2 text-xs"><Switch checked={adverseOnly} onCheckedChange={setAdverseOnly} data-testid="switch-adverse" />Adverse only</label>
              <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Filter unit, account, driver" className="h-8 w-56 text-xs" data-testid="input-search" />
            </div>
          </div>
          <VarianceBridge pnl={r.pnl} variances={r.variances} />
          {rows.length === 0 ? (
            <EmptyBlock title="Nothing breaches materiality" body="No variances match the current filter and threshold. Adjust thresholds in Settings to widen the net." />
          ) : (
            <div className="bg-card border rounded-md overflow-x-auto">
              <table className="w-full text-[12.5px]">
                <thead className="bg-muted/60 text-[10.5px] uppercase tracking-wider text-muted-foreground">
                  <tr>{["Business unit / account", "Class", "Actual", COMPARISON_LABEL[comparison], "Variance", "%", "Driver", "Source"].map((h, i) => <th key={h} className={cn("px-3 py-2 font-semibold", i >= 2 && i <= 5 ? "text-right" : "text-left")}>{h}</th>)}</tr>
                </thead>
                <tbody>
                  {rows.map((v) => (
                    <tr key={v.id} className="border-t align-top hover:bg-accent/30" data-testid={`row-variance-${v.id}`}>
                      <td className="px-3 py-2"><div className="font-medium">{v.businessUnit}</div><div className="text-muted-foreground">{v.account}</div></td>
                      <td className="px-3 py-2"><span className="text-[10.5px] px-1.5 py-0.5 rounded-sm bg-secondary">{v.classification}</span></td>
                      <td className="px-3 py-2 text-right num">{money(v.actual)}</td>
                      <td className="px-3 py-2 text-right num text-muted-foreground">{money(v.comparator)}</td>
                      <td className={cn("px-3 py-2 text-right num font-medium", v.favourable ? "fav" : "adv")}>{money(v.variance, { sign: true })}</td>
                      <td className={cn("px-3 py-2 text-right num", v.favourable ? "fav" : "adv")}>{pct(v.variancePercent)}</td>
                      <td className="px-3 py-2 max-w-[340px] text-muted-foreground">{v.driver}</td>
                      <td className="px-3 py-2"><Cite id={v.sourceId} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </>
  );
}
