import { useReport, money, pct, COMPARISON_LABEL, usePeriod } from "@/lib/period";
import { ErrorBlock, LoadingBlock, PageHeader, UnavailableBlock, EmptyBlock } from "@/components/states";
import { FinTable, TrendChart, VarianceBridge } from "@/components/finance";
import { CommentaryCard } from "@/components/commentary-editor";
import { GenerateButton } from "@/components/generate-button";
import { cn } from "@/lib/utils";

export default function Overview() {
  const q = useReport();
  const { comparison, view, openSource } = usePeriod();
  const r = q.data;
  return (
    <>
      <PageHeader eyebrow={r ? `${r.periodLabel} · ${view === "ytd" ? "Year to date" : "Month"} vs ${COMPARISON_LABEL[comparison]}` : "Overview"} title="Performance overview">
        <GenerateButton disabled={!r?.available} variant="outline" />
      </PageHeader>
      {q.isLoading && <LoadingBlock rows={10} />}
      {q.isError && <ErrorBlock error={q.error} onRetry={() => q.refetch()} />}
      {r && (
        <>
          <p className="text-[11.5px] text-muted-foreground -mt-3 mb-5" data-testid="text-data-note">{r.dataNote} · Engine: {r.engine}</p>
          {!r.available ? (
            <div className="space-y-5">
              <UnavailableBlock />
              {r.trends.length > 0 && <div className="grid lg:grid-cols-2 gap-4"><TrendChart data={r.trends} metric="revenue" /><TrendChart data={r.trends} metric="opex" /></div>}
            </div>
          ) : (
            <div className="space-y-5">
              <div className="grid grid-cols-2 lg:grid-cols-4 border rounded-md bg-card divide-x divide-y lg:divide-y-0 overflow-hidden">
                {r.pnl.filter((x, i) => i === 0 || /gross|profit|ebitda|opex|operating exp/i.test(x.name)).slice(0, 4).map((x) => (
                  <button key={x.id} onClick={() => openSource(x.sourceId)} className="text-left px-4 py-3.5 hover:bg-accent/40 transition-colors" data-testid={`stat-${x.id}`}>
                    <div className="eyebrow">{x.name}</div>
                    <div className="num text-2xl font-semibold mt-1.5">{money(x.actual, { compact: true })}</div>
                    <div className={cn("text-[11.5px] num mt-0.5", x.favourable ? "fav" : "adv")}>{money(x.variance, { compact: true, sign: true })} ({pct(x.variancePercent)}) vs {COMPARISON_LABEL[comparison].toLowerCase()}</div>
                  </button>
                ))}
              </div>
              <div className="grid xl:grid-cols-[minmax(0,1.35fr)_minmax(0,1fr)] gap-5 items-start">
                <div className="space-y-5 min-w-0">
                  <FinTable rows={r.pnl} title="Profit and loss" testId="table-pnl" />
                  <VarianceBridge pnl={r.pnl} variances={r.variances} />
                  <div className="grid lg:grid-cols-2 gap-4"><TrendChart data={r.trends} metric="revenue" /><TrendChart data={r.trends} metric="opex" /></div>
                  <FinTable rows={r.businessUnits} title="Business units" testId="table-bu" />
                </div>
                <aside className="space-y-3 xl:sticky xl:top-16 min-w-0">
                  <div className="flex items-center justify-between">
                    <div className="eyebrow">Leadership commentary</div>
                    <span className="text-[11px] text-muted-foreground">{r.commentary.filter((c) => c.status === "Approved").length}/{r.commentary.length} approved</span>
                  </div>
                  {r.commentary.length === 0 ? (
                    <EmptyBlock title="No commentary yet" body="Draft narrative for this period from the ledger. Every sentence will carry citations." action={<GenerateButton />} />
                  ) : (
                    r.commentary.map((c) => <CommentaryCard key={c.id} c={c} compact />)
                  )}
                </aside>
              </div>
            </div>
          )}
        </>
      )}
    </>
  );
}
