import { useEffect, useState } from "react";
import { useGetSettings, SettingsAudience, type ReportInputAudience } from "@workspace/api-client-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useReport, COMPARISON_LABEL, usePeriod } from "@/lib/period";
import { ErrorBlock, LoadingBlock, PageHeader, UnavailableBlock, EmptyBlock } from "@/components/states";
import { CommentaryCard } from "@/components/commentary-editor";
import { GenerateButton } from "@/components/generate-button";
import { FinTable } from "@/components/finance";
import { cn } from "@/lib/utils";

const FILTERS = ["All", "Draft", "Reviewed", "Approved"] as const;

export default function CommentaryPage() {
  const q = useReport();
  const settings = useGetSettings();
  const { comparison } = usePeriod();
  const [aud, setAud] = useState<ReportInputAudience | "">("");
  const [filter, setFilter] = useState<(typeof FILTERS)[number]>("All");
  useEffect(() => {
    if (!aud && settings.data) setAud(settings.data.audience);
  }, [settings.data, aud]);
  const r = q.data;
  const list = (r?.commentary ?? []).filter((c) => filter === "All" || c.status === filter);
  return (
    <>
      <PageHeader eyebrow={r ? `${r.periodLabel} vs ${COMPARISON_LABEL[comparison]}` : "Narrative"} title="Commentary workbench">
        <Select value={aud || undefined} onValueChange={(v) => setAud(v as ReportInputAudience)}>
          <SelectTrigger className="h-8 w-[210px] text-xs bg-card" data-testid="select-audience"><SelectValue placeholder="Audience" /></SelectTrigger>
          <SelectContent>{Object.values(SettingsAudience).map((a) => <SelectItem key={a} value={a}>{a}</SelectItem>)}</SelectContent>
        </Select>
        <GenerateButton audience={aud || undefined} disabled={!r?.available} />
      </PageHeader>
      {q.isLoading && <LoadingBlock />}
      {q.isError && <ErrorBlock error={q.error} onRetry={() => q.refetch()} />}
      {r && !r.available && <UnavailableBlock note={r.dataNote} />}
      {r && r.available && (
        <div className="grid xl:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)] gap-5 items-start">
          <div className="space-y-4 xl:sticky xl:top-16 min-w-0">
            <FinTable rows={r.pnl} title="Figures referenced" testId="table-pnl-ref" />
            <p className="text-[11px] text-muted-foreground">Regenerating replaces drafts for this period and audience on the server. Edits keep each sentence's original citations.</p>
          </div>
          <div className="space-y-3 min-w-0">
            <div className="flex gap-1">
              {FILTERS.map((f) => (
                <button key={f} onClick={() => setFilter(f)} data-testid={`filter-${f.toLowerCase()}`}
                  className={cn("text-xs px-2.5 py-1 rounded-sm border transition-colors", filter === f ? "bg-primary text-primary-foreground border-primary" : "bg-card hover:bg-accent")}>
                  {f} <span className="opacity-60 num">{f === "All" ? r.commentary.length : r.commentary.filter((c) => c.status === f).length}</span>
                </button>
              ))}
            </div>
            {r.commentary.length === 0 ? (
              <EmptyBlock title="No commentary for this period" body="Choose an audience and generate. The server drafts each section with sentence-level ledger citations." action={<GenerateButton audience={aud || undefined} />} />
            ) : list.length === 0 ? (
              <EmptyBlock title={`Nothing ${filter.toLowerCase()}`} body="No sections are at this stage yet." />
            ) : (
              list.map((c) => <CommentaryCard key={c.id} c={c} />)
            )}
          </div>
        </div>
      )}
    </>
  );
}
