import { useEffect, useRef, useState } from "react";
import { useAskAssistant, useGetSettings, type Sentence } from "@workspace/api-client-react";
import { ArrowUp, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Cite } from "@/components/source-sheet";
import { PageHeader } from "@/components/states";
import { errMsg, usePeriod, MONTHS_LONG, COMPARISON_LABEL } from "@/lib/period";
import { cn } from "@/lib/utils";

type Msg = { role: "user" | "assistant" | "error"; text?: string; sentences?: Sentence[]; engine?: string };
const PROMPTS = ["What drove the largest adverse variance this month?", "Summarise gross margin performance for the CFO.", "Which business unit is furthest behind budget YTD?", "Explain the OpEx movement versus prior year."];

export default function Assistant() {
  const { month, view, comparison } = usePeriod();
  const settings = useGetSettings();
  const ask = useAskAssistant();
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => end.current?.scrollIntoView({ behavior: "smooth" }), [msgs, ask.isPending]);

  const send = (text: string) => {
    const t = text.trim();
    if (!t || ask.isPending) return;
    setMsgs((m) => [...m, { role: "user", text: t }]);
    setInput("");
    ask.mutate(
      { data: { month, view, comparison, audience: settings.data?.audience ?? "CFO", message: t } },
      {
        onSuccess: (r) => setMsgs((m) => [...m, { role: "assistant", sentences: r.sentences, engine: r.engine }]),
        onError: (e) => setMsgs((m) => [...m, { role: "error", text: errMsg(e) }]),
      },
    );
  };

  return (
    <div className="flex flex-col h-[calc(100dvh-110px)]">
      <PageHeader eyebrow={`Context: ${MONTHS_LONG[month - 1]} 2026 · ${view === "ytd" ? "YTD" : "Month"} vs ${COMPARISON_LABEL[comparison]}`} title="Finance assistant" />
      <div className="flex-1 overflow-y-auto bg-card border rounded-md p-4 md:p-6 space-y-4" data-testid="list-messages">
        {msgs.length === 0 && (
          <div className="max-w-xl mx-auto text-center py-8">
            <div className="font-serif text-xl">Ask about the numbers</div>
            <p className="text-sm text-muted-foreground mt-1">Answers are grounded in the seeded ledger and cite their sources. Click any citation to inspect the records.</p>
            <div className="grid sm:grid-cols-2 gap-2 mt-5">
              {PROMPTS.map((p, i) => <button key={p} onClick={() => send(p)} className="text-left text-[12.5px] border rounded-md px-3 py-2 hover:bg-accent transition-colors" data-testid={`button-prompt-${i}`}>{p}</button>)}
            </div>
          </div>
        )}
        {msgs.map((m, i) => (
          <div key={i} className={cn("flex page-in", m.role === "user" ? "justify-end" : "justify-start")} data-testid={`msg-${m.role}-${i}`}>
            <div className={cn("max-w-[78%] rounded-md px-3.5 py-2.5 text-[13.5px] leading-relaxed",
              m.role === "user" ? "bg-primary text-primary-foreground" : m.role === "error" ? "bg-destructive/10 text-destructive border border-destructive/30" : "bg-secondary")}>
              {m.text}
              {m.sentences?.map((s, j) => <span key={j}>{s.text}{s.sourceIds.map((id) => <Cite key={id} id={id} />)} </span>)}
              {m.engine && <div className="text-[10px] text-muted-foreground mt-1.5">{m.engine}</div>}
            </div>
          </div>
        ))}
        {ask.isPending && <div className="flex items-center gap-2 text-xs text-muted-foreground"><Loader2 className="h-3.5 w-3.5 animate-spin" />Reading the ledger...</div>}
        <div ref={end} />
      </div>
      <form className="mt-3 flex gap-2 items-end" onSubmit={(e) => { e.preventDefault(); send(input); }}>
        <Textarea value={input} onChange={(e) => setInput(e.target.value)} maxLength={4000} placeholder="Ask a question about this period..." className="min-h-[46px] max-h-40 bg-card text-[13.5px]"
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input); } }} data-testid="input-message" />
        <Button type="submit" size="icon" className="h-[46px] w-[46px]" disabled={!input.trim() || ask.isPending} data-testid="button-send"><ArrowUp className="h-4 w-4" /></Button>
      </form>
    </div>
  );
}
