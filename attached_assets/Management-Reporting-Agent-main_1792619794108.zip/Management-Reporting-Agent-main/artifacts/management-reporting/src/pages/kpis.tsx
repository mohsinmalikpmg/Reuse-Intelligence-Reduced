import { ArrowDownRight, ArrowRight, ArrowUpRight } from "lucide-react";
import { useReport, kpiValue, usePeriod } from "@/lib/period";
import { ErrorBlock, LoadingBlock, PageHeader, UnavailableBlock, EmptyBlock } from "@/components/states";
import { Cite } from "@/components/source-sheet";

export default function Kpis() {
  const q = useReport();
  const { openSource } = usePeriod();
  const r = q.data;
  return (
    <>
      <PageHeader eyebrow={r ? r.periodLabel : "Scorecard"} title="KPI scorecard" />
      {q.isLoading && <LoadingBlock />}
      {q.isError && <ErrorBlock error={q.error} onRetry={() => q.refetch()} />}
      {r && !r.available && <UnavailableBlock note={r.dataNote} />}
      {r && r.available && (r.kpis.length === 0 ? <EmptyBlock title="No KPIs defined" body="The report returned no KPIs for this period." /> : (
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">
          {r.kpis.map((k, i) => {
            const Icon = k.trend === "up" ? ArrowUpRight : k.trend === "down" ? ArrowDownRight : ArrowRight;
            const vsBudget = k.budget ? ((k.current - k.budget) / Math.abs(k.budget)) * 100 : null;
            return (
              <div key={k.name} className="bg-card border rounded-md p-4 flex flex-col" data-testid={`card-kpi-${i}`}>
                <div className="flex items-start justify-between">
                  <div className="eyebrow">{k.name}</div>
                  <Icon className="h-4 w-4 text-primary" />
                </div>
                <button onClick={() => openSource(k.sourceId)} className="num text-3xl font-semibold mt-2 text-left hover:text-primary/80" data-testid={`text-kpi-value-${i}`}>{kpiValue(k.current, k.unit)}</button>
                <div className="grid grid-cols-3 gap-2 mt-3 text-[11.5px] border-t pt-2.5">
                  <div><div className="text-muted-foreground">YTD</div><div className="num">{kpiValue(k.ytd, k.unit)}</div></div>
                  <div><div className="text-muted-foreground">Budget</div><div className="num">{kpiValue(k.budget, k.unit)}</div></div>
                  <div><div className="text-muted-foreground">Prior</div><div className="num">{kpiValue(k.prior, k.unit)}</div></div>
                </div>
                {vsBudget !== null && (
                  <div className="h-1 bg-muted rounded-full mt-3 overflow-hidden">
                    <div className="h-full bg-primary origin-left" style={{ transform: `scaleX(${Math.min(1, Math.max(0.02, k.current / (k.budget || 1)))})` }} />
                  </div>
                )}
                <p className="text-[12.5px] text-muted-foreground mt-3 leading-relaxed flex-1">{k.explanation} <Cite id={k.sourceId} /></p>
              </div>
            );
          })}
        </div>
      ))}
    </>
  );
}
