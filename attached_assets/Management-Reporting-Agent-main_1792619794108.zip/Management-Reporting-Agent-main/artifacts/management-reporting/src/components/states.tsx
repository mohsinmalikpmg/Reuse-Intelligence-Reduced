import { AlertTriangle, CalendarOff, RotateCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { errMsg, MONTHS_LONG, usePeriod } from "@/lib/period";

export function LoadingBlock({ rows = 6 }: { rows?: number }) {
  return (
    <div className="space-y-3" data-testid="state-loading">
      <Skeleton className="h-8 w-1/3" />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-20" />)}
      </div>
      {Array.from({ length: rows }).map((_, i) => <Skeleton key={i} className="h-7" style={{ opacity: 1 - i * 0.1 }} />)}
    </div>
  );
}

export function ErrorBlock({ error, onRetry }: { error: unknown; onRetry?: () => void }) {
  return (
    <div className="border border-destructive/30 bg-destructive/5 rounded-md p-5 flex items-start gap-3" data-testid="state-error">
      <AlertTriangle className="h-5 w-5 text-destructive mt-0.5" />
      <div className="flex-1">
        <div className="font-semibold text-sm">Could not load data</div>
        <div className="text-sm text-muted-foreground mt-1">{errMsg(error)}</div>
      </div>
      {onRetry && (
        <Button size="sm" variant="outline" onClick={onRetry} data-testid="button-retry">
          <RotateCw className="h-3.5 w-3.5 mr-1.5" /> Retry
        </Button>
      )}
    </div>
  );
}

export function UnavailableBlock({ note }: { note?: string }) {
  const { month, setMonth } = usePeriod();
  return (
    <div className="border border-dashed border-primary/30 bg-card rounded-md px-8 py-14 text-center" data-testid="state-unavailable">
      <CalendarOff className="h-8 w-8 mx-auto text-primary/60" />
      <h2 className="font-serif text-2xl mt-4">{MONTHS_LONG[month - 1]} actuals are not yet closed</h2>
      <p className="text-sm text-muted-foreground mt-2 max-w-lg mx-auto">
        No actual ledger postings exist for this period, so performance cannot be reported. This is not zero performance.
        {note ? ` ${note}` : ""}
      </p>
      <Button className="mt-6" onClick={() => setMonth(9)} data-testid="button-goto-latest">Go to September (latest close)</Button>
    </div>
  );
}

export function EmptyBlock({ title, body, action }: { title: string; body: string; action?: React.ReactNode }) {
  return (
    <div className="border border-dashed rounded-md px-6 py-10 text-center bg-card/50" data-testid="state-empty">
      <div className="font-serif text-lg">{title}</div>
      <p className="text-sm text-muted-foreground mt-1 max-w-md mx-auto">{body}</p>
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function PageHeader({ eyebrow, title, children }: { eyebrow: string; title: string; children?: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
      <div>
        <div className="eyebrow">{eyebrow}</div>
        <h1 className="font-serif text-3xl font-semibold tracking-tight mt-1" data-testid="text-page-title">{title}</h1>
      </div>
      {children && <div className="flex items-center gap-2">{children}</div>}
    </div>
  );
}
