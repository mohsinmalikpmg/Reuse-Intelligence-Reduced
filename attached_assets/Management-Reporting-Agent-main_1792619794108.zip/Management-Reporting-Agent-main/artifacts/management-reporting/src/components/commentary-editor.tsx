import { useEffect, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useUpdateCommentary, getGetReportQueryKey, type Commentary, type CommentaryStatus } from "@workspace/api-client-react";
import { Check, Pencil, Loader2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Cite } from "@/components/source-sheet";
import { errMsg } from "@/lib/period";
import { cn } from "@/lib/utils";

const STATUS_STYLE: Record<string, string> = {
  Draft: "bg-muted text-muted-foreground border-border",
  Reviewed: "bg-accent text-accent-foreground border-primary/20",
  Approved: "bg-primary text-primary-foreground border-primary",
};

export function StatusPill({ status }: { status: string }) {
  return <span className={cn("text-[10px] uppercase tracking-wider font-semibold px-1.5 py-0.5 rounded-sm border", STATUS_STYLE[status])} data-testid="status-commentary">{status}</span>;
}

export function CommentaryCard({ c, compact }: { c: Commentary; compact?: boolean }) {
  const qc = useQueryClient();
  const { toast } = useToast();
  const update = useUpdateCommentary();
  const [editing, setEditing] = useState(false);
  const [texts, setTexts] = useState<string[]>(c.sentences.map((s) => s.text));
  const [saved, setSaved] = useState(0);
  const initFor = useRef<string>("");
  useEffect(() => {
    const key = `${c.id}-${c.updatedAt}`;
    if (!editing && initFor.current !== key) {
      initFor.current = key;
      setTexts(c.sentences.map((s) => s.text));
    }
  }, [c, editing]);

  const save = (status: CommentaryStatus, closeEditor = true) => {
    const nums = (t: string) => t.match(/[$]?\d[\d,.]*%?[MK]?/g) ?? [];
    const bad = c.sentences.findIndex((s, i) => nums(s.text).some((n) => !(texts[i] ?? "").includes(n)));
    if (closeEditor && bad >= 0) {
      toast({ title: "Figures must stay intact", description: `Sentence ${bad + 1} changed or removed a sourced number. Edit wording only.`, variant: "destructive" });
      return;
    }
    const sentences = c.sentences.map((s, i) => ({ text: (texts[i] ?? s.text).trim() || s.text, sourceIds: s.sourceIds }));
    update.mutate(
      { id: c.id, data: { sentences, status } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: [getGetReportQueryKey()[0]] });
          if (closeEditor) setEditing(false);
          setSaved((n) => n + 1);
          toast({ title: status === c.status ? "Commentary saved" : `Marked ${status}`, description: c.title });
        },
        onError: (e) => toast({ title: "Save failed", description: errMsg(e), variant: "destructive" }),
      },
    );
  };

  let citeN = 0;
  return (
    <article className="bg-card border rounded-md transition-shadow hover:shadow-sm" data-testid={`card-commentary-${c.id}`}>
      <header className="flex items-center justify-between gap-2 px-4 pt-3 pb-2 border-b">
        <div className="min-w-0">
          <div className="eyebrow truncate">{c.section}</div>
          <h3 className="font-serif text-[17px] font-semibold leading-tight truncate">{c.title}</h3>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          {saved > 0 && !update.isPending && <span key={saved} className="save-flash text-[11px] fav flex items-center gap-1"><Check className="h-3 w-3" />Saved</span>}
          <StatusPill status={c.status} />
        </div>
      </header>
      <div className="px-4 py-3">
        {!editing ? (
          <p className={cn("text-[13.5px] leading-relaxed", compact && "text-[13px]")} data-testid={`text-commentary-${c.id}`}>
            {c.sentences.map((s, i) => (
              <span key={i}>
                {s.text}
                {s.sourceIds.map((sid) => <Cite key={sid} id={sid} n={++citeN} />)}{" "}
              </span>
            ))}
          </p>
        ) : (
          <div className="space-y-2.5">
            {c.sentences.map((s, i) => (
              <div key={i}>
                <Textarea
                  value={texts[i] ?? ""}
                  onChange={(e) => setTexts((t) => t.map((x, j) => (j === i ? e.target.value : x)))}
                  className="text-[13px] min-h-[58px] bg-background"
                  data-testid={`input-sentence-${c.id}-${i}`}
                />
                <div className="flex flex-wrap items-center gap-1 mt-1 text-[10px] text-muted-foreground">
                  Citations kept: {s.sourceIds.length ? s.sourceIds.map((sid) => <Cite key={sid} id={sid} />) : <span className="adv">none</span>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <footer className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 border-t bg-muted/40 text-[11px] text-muted-foreground">
        <span>{c.audience} · {c.engine} · {new Date(c.updatedAt).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}</span>
        <div className="flex items-center gap-1.5">
          {editing ? (
            <>
              <Button size="sm" variant="ghost" className="h-7" onClick={() => { setEditing(false); setTexts(c.sentences.map((s) => s.text)); }} data-testid={`button-cancel-${c.id}`}><X className="h-3.5 w-3.5 mr-1" />Cancel</Button>
              <Button size="sm" className="h-7" disabled={update.isPending} onClick={() => save("Draft")} data-testid={`button-save-${c.id}`}>
                {update.isPending ? <Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" /> : <Check className="h-3.5 w-3.5 mr-1" />}Save as draft
              </Button>
            </>
          ) : (
            <>
              <Button size="sm" variant="ghost" className="h-7" onClick={() => setEditing(true)} data-testid={`button-edit-${c.id}`}><Pencil className="h-3.5 w-3.5 mr-1" />Edit</Button>
              {c.status === "Draft" && <Button size="sm" variant="outline" className="h-7" disabled={update.isPending} onClick={() => save("Reviewed", false)} data-testid={`button-review-${c.id}`}>Mark reviewed</Button>}
              {c.status === "Reviewed" && (
                <>
                  <Button size="sm" variant="ghost" className="h-7" disabled={update.isPending} onClick={() => save("Draft", false)} data-testid={`button-reopen-${c.id}`}>Return to draft</Button>
                  <Button size="sm" className="h-7" disabled={update.isPending} onClick={() => save("Approved", false)} data-testid={`button-approve-${c.id}`}>Approve</Button>
                </>
              )}
              {c.status === "Approved" && <Button size="sm" variant="ghost" className="h-7" disabled={update.isPending} onClick={() => save("Reviewed", false)} data-testid={`button-unapprove-${c.id}`}>Revoke approval</Button>}
              {update.isPending && <Loader2 className="h-3.5 w-3.5 animate-spin" />}
            </>
          )}
        </div>
      </footer>
    </article>
  );
}
