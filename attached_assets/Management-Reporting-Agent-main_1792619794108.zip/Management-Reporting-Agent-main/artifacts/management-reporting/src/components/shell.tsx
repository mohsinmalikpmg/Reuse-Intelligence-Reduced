import type { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useHealthCheck } from "@workspace/api-client-react";
import { BarChart3, FileText, Gauge, LayoutDashboard, MessageSquare, Package, Settings2, TrendingDown } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MONTHS, usePeriod } from "@/lib/period";
import { cn } from "@/lib/utils";

const NAV = [
  { href: "/", label: "Overview", icon: LayoutDashboard },
  { href: "/variances", label: "Variances", icon: TrendingDown },
  { href: "/commentary", label: "Commentary", icon: FileText },
  { href: "/kpis", label: "KPI scorecard", icon: Gauge },
  { href: "/packs", label: "Monthly packs", icon: Package },
  { href: "/assistant", label: "Assistant", icon: MessageSquare },
  { href: "/settings", label: "Settings", icon: Settings2 },
];

function Seg<T extends string>({ value, options, onChange, id }: { value: T; options: [T, string][]; onChange: (v: T) => void; id: string }) {
  return (
    <div className="inline-flex border rounded-md bg-card p-0.5">
      {options.map(([v, l]) => (
        <button key={v} onClick={() => onChange(v)} data-testid={`toggle-${id}-${v}`}
          className={cn("px-2.5 h-7 text-xs font-medium rounded-[4px] transition-colors", value === v ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground")}>
          {l}
        </button>
      ))}
    </div>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  const [loc] = useLocation();
  const { month, view, comparison, setMonth, setView, setComparison } = usePeriod();
  const health = useHealthCheck();
  const ok = health.data?.status === "ok" || (!!health.data && !health.isError);
  return (
    <div className="min-h-[100dvh] flex flex-col md:flex-row">
      <aside className="md:w-56 shrink-0 bg-sidebar text-sidebar-foreground md:min-h-[100dvh] md:sticky md:top-0 md:h-[100dvh] flex md:flex-col">
        <div className="px-5 py-5 hidden md:block">
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded-sm bg-sidebar-primary text-sidebar-primary-foreground grid place-items-center"><BarChart3 className="h-4 w-4" /></div>
            <div className="leading-tight">
              <div className="font-serif text-[15px] font-semibold text-white">Management</div>
              <div className="text-[10px] tracking-widest uppercase opacity-60">Reporting Agent</div>
            </div>
          </div>
        </div>
        <nav className="flex md:flex-col gap-0.5 px-2 py-2 md:py-0 overflow-x-auto flex-1">
          {NAV.map((n) => {
            const active = n.href === "/" ? loc === "/" : loc.startsWith(n.href);
            return (
              <Link key={n.href} href={n.href} data-testid={`link-nav-${n.label.toLowerCase().replace(/\s/g, "-")}`}
                className={cn("flex items-center gap-2.5 px-3 py-2 rounded-md text-[13px] whitespace-nowrap transition-colors",
                  active ? "bg-sidebar-accent text-white font-medium shadow-[inset_2px_0_0_hsl(var(--sidebar-primary))]" : "hover:bg-sidebar-accent/60 hover:text-white")}>
                <n.icon className="h-4 w-4 opacity-80" />{n.label}
              </Link>
            );
          })}
        </nav>
        <div className="hidden md:block px-5 py-4 text-[10.5px] leading-snug opacity-70 border-t border-sidebar-border">
          <div className="flex items-center gap-1.5 mb-1.5">
            <span className={cn("h-1.5 w-1.5 rounded-full", health.isLoading ? "bg-yellow-300" : ok ? "bg-emerald-400" : "bg-red-400")} />
            <span data-testid="status-api">{health.isLoading ? "Connecting" : ok ? "API connected" : "API unreachable"}</span>
          </div>
          Seeded sample data for FY2026. Figures are illustrative, not actual results.
        </div>
      </aside>
      <div className="flex-1 min-w-0 flex flex-col">
        <div className="sticky top-0 z-20 bg-background/90 backdrop-blur border-b">
          <div className="px-4 md:px-8 py-2.5 flex flex-wrap items-center gap-3">
            <div className="eyebrow mr-1 hidden lg:block">FY2026 period</div>
            <Select value={String(month)} onValueChange={(v) => setMonth(Number(v))}>
              <SelectTrigger className="h-8 w-[118px] text-xs bg-card" data-testid="select-month"><SelectValue /></SelectTrigger>
              <SelectContent>
                {MONTHS.map((m, i) => (
                  <SelectItem key={m} value={String(i + 1)}>{m} 2026{i >= 9 ? "  · not closed" : ""}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Seg id="view" value={view} onChange={setView} options={[["month", "Month"], ["ytd", "YTD"]]} />
            <div className="flex items-center gap-1.5">
              <span className="text-xs text-muted-foreground">vs</span>
              <Seg id="comparison" value={comparison} onChange={setComparison} options={[["budget", "Budget"], ["forecast", "Forecast"], ["prior", "Prior year"]]} />
            </div>
            <span className="ml-auto text-[10.5px] uppercase tracking-wider font-semibold px-2 py-1 rounded-sm border border-dashed border-primary/30 text-primary/80" data-testid="badge-sample-data">Sample data</span>
          </div>
        </div>
        <main key={loc} className="page-in px-4 md:px-8 py-6 flex-1 max-w-[1500px] w-full">{children}</main>
      </div>
    </div>
  );
}
