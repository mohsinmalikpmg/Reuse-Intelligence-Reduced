import { Bar, CartesianGrid, Cell, ComposedChart, Line, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { FinancialRow, TrendPoint, Variance } from "@workspace/api-client-react";
import { COMPARISON_LABEL, money, pct, usePeriod } from "@/lib/period";
import { cn } from "@/lib/utils";

const NAVY = "hsl(221 62% 24%)";
const STEEL = "hsl(210 50% 62%)";
const GREY = "hsl(218 12% 66%)";
const GREEN = "hsl(152 50% 33%)";
const RED = "hsl(2 62% 48%)";

const isTotal = (name: string) => /total|gross|profit|ebitda|net |operating income|margin/i.test(name);

export function FinTable({ rows, title, testId }: { rows: FinancialRow[]; title: string; testId: string }) {
  const { comparison, openSource } = usePeriod();
  return (
    <div className="bg-card border rounded-md overflow-hidden" data-testid={testId}>
      <div className="px-4 py-2.5 border-b flex items-center justify-between">
        <h3 className="font-serif text-[16px] font-semibold">{title}</h3>
        <span className="text-[11px] text-muted-foreground">USD · click a row for ledger</span>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-[12.5px]">
          <thead>
            <tr className="text-[10.5px] uppercase tracking-wider text-muted-foreground bg-muted/60">
              <th className="text-left font-semibold px-4 py-2">Line</th>
              <th className="text-right font-semibold px-3 py-2">Actual</th>
              <th className="text-right font-semibold px-3 py-2">{COMPARISON_LABEL[comparison]}</th>
              <th className="text-right font-semibold px-3 py-2">Variance</th>
              <th className="text-right font-semibold px-4 py-2">Var %</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => {
              const tot = isTotal(r.name);
              return (
                <tr key={r.id} onClick={() => openSource(r.sourceId)} data-testid={`row-fin-${r.id}`}
                  className={cn("border-t cursor-pointer hover:bg-accent/50 transition-colors", tot && "bg-secondary/50 font-semibold border-t-primary/25")}>
                  <td className="px-4 py-1.5">{r.name}</td>
                  <td className="px-3 py-1.5 text-right num">{money(r.actual)}</td>
                  <td className="px-3 py-1.5 text-right num text-muted-foreground">{money(r.comparator)}</td>
                  <td className={cn("px-3 py-1.5 text-right num", r.variance === 0 ? "" : r.favourable ? "fav" : "adv")}>{money(r.variance, { sign: true })}</td>
                  <td className="px-4 py-1.5 text-right">
                    <span className={cn("num inline-block min-w-[58px] text-right px-1.5 rounded-sm text-[11.5px]", r.variance === 0 ? "" : r.favourable ? "fav bg-emerald-50" : "adv bg-red-50")}>{pct(r.variancePercent)}</span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ttMoney(v: unknown) {
  return typeof v === "number" ? money(v) : "Not closed";
}

export function TrendChart({ data, metric }: { data: TrendPoint[]; metric: "revenue" | "opex" }) {
  const { comparison } = usePeriod();
  const cmpKey = comparison === "prior" ? `${metric}Prior` : `${metric}Budget`;
  const cmpLabel = comparison === "prior" ? "Prior year" : "Budget";
  const otherKey = comparison === "prior" ? `${metric}Budget` : `${metric}Prior`;
  const otherLabel = comparison === "prior" ? "Budget" : "Prior year";
  return (
    <div className="bg-card border rounded-md p-4" data-testid={`chart-${metric}`}>
      <div className="flex items-baseline justify-between mb-2">
        <h3 className="font-serif text-[16px] font-semibold">{metric === "revenue" ? "Revenue" : "Operating expenses"} by month</h3>
        <div className="flex gap-3 text-[11px] text-muted-foreground">
          <span className="flex items-center gap-1"><i className="h-2.5 w-2.5 inline-block" style={{ background: NAVY }} />Actual</span>
          <span className="flex items-center gap-1"><i className="h-0.5 w-3 inline-block" style={{ background: STEEL }} />{cmpLabel}</span>
          <span className="flex items-center gap-1"><i className="h-0.5 w-3 inline-block border-t border-dashed" style={{ borderColor: GREY }} />{otherLabel}</span>
        </div>
      </div>
      <div className="h-[220px]">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={data} margin={{ top: 6, right: 6, left: 0, bottom: 0 }}>
            <CartesianGrid vertical={false} stroke="hsl(216 20% 90%)" />
            <XAxis dataKey="month" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
            <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} width={54} tickFormatter={(v) => money(v, { compact: true })} />
            <Tooltip formatter={(v, n) => [ttMoney(v), n]} contentStyle={{ fontSize: 12, borderRadius: 6 }} />
            <Bar dataKey={metric} name="Actual" fill={NAVY} radius={[2, 2, 0, 0]} maxBarSize={26} />
            <Line dataKey={cmpKey} name={cmpLabel} stroke={STEEL} strokeWidth={2} dot={false} />
            <Line dataKey={otherKey} name={otherLabel} stroke={GREY} strokeDasharray="4 3" strokeWidth={1.5} dot={false} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
      <p className="text-[10.5px] text-muted-foreground mt-1">Oct–Dec bars absent: actuals not yet closed.</p>
    </div>
  );
}

export function VarianceBridge({ pnl, variances }: { pnl: FinancialRow[]; variances: Variance[] }) {
  const { comparison } = usePeriod();
  const anchor = [...pnl].reverse().find((r) => /profit|ebitda|net/i.test(r.name)) ?? pnl[pnl.length - 1];
  if (!anchor) return null;
  const drivers = [...variances].sort((a, b) => Math.abs(b.variance) - Math.abs(a.variance)).slice(0, 6);
  const impact = (v: Variance) => (v.favourable ? Math.abs(v.variance) : -Math.abs(v.variance));
  const explained = drivers.reduce((a, v) => a + impact(v), 0);
  const other = anchor.actual - anchor.comparator - explained;
  type Step = { name: string; base: number; value: number; kind: "total" | "pos" | "neg"; raw: number };
  const steps: Step[] = [{ name: COMPARISON_LABEL[comparison], base: 0, value: anchor.comparator, kind: "total", raw: anchor.comparator }];
  let run = anchor.comparator;
  const push = (name: string, d: number) => {
    steps.push({ name, base: d >= 0 ? run : run + d, value: Math.abs(d), kind: d >= 0 ? "pos" : "neg", raw: d });
    run += d;
  };
  drivers.forEach((v) => push(v.businessUnit ? `${v.account} · ${v.businessUnit}` : v.name, impact(v)));
  if (Math.abs(other) >= 1) push("Other", other);
  steps.push({ name: "Actual", base: 0, value: anchor.actual, kind: "total", raw: anchor.actual });
  return (
    <div className="bg-card border rounded-md p-4" data-testid="chart-bridge">
      <div className="flex items-baseline justify-between mb-2">
        <h3 className="font-serif text-[16px] font-semibold">{anchor.name} bridge: {COMPARISON_LABEL[comparison].toLowerCase()} to actual</h3>
        <span className="text-[11px] text-muted-foreground">Top {drivers.length} material drivers, remainder in Other</span>
      </div>
      <div className="h-[260px]">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart data={steps} margin={{ top: 8, right: 6, left: 0, bottom: 0 }}>
            <CartesianGrid vertical={false} stroke="hsl(216 20% 90%)" />
            <XAxis dataKey="name" tick={{ fontSize: 10 }} tickLine={false} axisLine={false} interval={0} tickFormatter={(s: string) => (s.length > 16 ? `${s.slice(0, 15)}…` : s)} />
            <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} width={54} tickFormatter={(v) => money(v, { compact: true })} />
            <Tooltip cursor={{ fill: "hsl(212 55% 92% / .5)" }} contentStyle={{ fontSize: 12, borderRadius: 6 }}
              formatter={(_v, n, item) => (n === "value" ? [money((item.payload as Step).raw, { sign: (item.payload as Step).kind !== "total" }), "Impact"] : [null, null])} />
            <ReferenceLine y={0} stroke="hsl(216 20% 75%)" />
            <Bar dataKey="base" stackId="b" fill="transparent" isAnimationActive={false} />
            <Bar dataKey="value" stackId="b" radius={[2, 2, 0, 0]}>
              {steps.map((s, i) => <Cell key={i} fill={s.kind === "total" ? NAVY : s.kind === "pos" ? GREEN : RED} />)}
            </Bar>
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
