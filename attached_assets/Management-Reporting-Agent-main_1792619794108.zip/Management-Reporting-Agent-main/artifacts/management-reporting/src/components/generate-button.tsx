import { useQueryClient } from "@tanstack/react-query";
import { useGenerateCommentary, useGetSettings, useSaveSettings, getGetSettingsQueryKey, getGetReportQueryKey, type ReportInputAudience } from "@workspace/api-client-react";
import { Loader2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { errMsg, usePeriod } from "@/lib/period";

export function GenerateButton({ audience, disabled, variant = "default" }: { audience?: ReportInputAudience; disabled?: boolean; variant?: "default" | "outline" }) {
  const { month, view, comparison } = usePeriod();
  const settings = useGetSettings();
  const gen = useGenerateCommentary();
  const saveSettings = useSaveSettings();
  const qc = useQueryClient();
  const { toast } = useToast();
  const aud = audience ?? settings.data?.audience ?? "CFO";
  return (
    <Button
      variant={variant}
      size="sm"
      disabled={disabled || gen.isPending || saveSettings.isPending}
      onClick={async () => {
        if (settings.data && aud !== settings.data.audience) {
          try {
            const s = await saveSettings.mutateAsync({ data: { ...settings.data, audience: aud } });
            qc.setQueryData(getGetSettingsQueryKey(), s);
          } catch (e) {
            toast({ title: "Could not switch audience", description: errMsg(e), variant: "destructive" });
            return;
          }
        }
        gen.mutate(
          { data: { month, view, comparison, audience: aud } },
          {
            onSuccess: (list) => {
              qc.invalidateQueries({ queryKey: [getGetReportQueryKey()[0]] });
              toast({ title: "Commentary generated", description: `${list.length} sections drafted for ${aud}.` });
            },
            onError: (e) => toast({ title: "Generation failed", description: errMsg(e), variant: "destructive" }),
          },
        );
      }}
      data-testid="button-generate"
    >
      {gen.isPending ? <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5 mr-1.5" />}
      {gen.isPending ? "Drafting..." : "Generate commentary"}
    </Button>
  );
}
