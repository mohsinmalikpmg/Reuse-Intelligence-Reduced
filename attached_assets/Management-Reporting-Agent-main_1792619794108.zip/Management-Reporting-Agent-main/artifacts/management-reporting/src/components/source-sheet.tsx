import { useGetSource, getGetSourceQueryKey } from "@workspace/api-client-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Skeleton } from "@/components/ui/skeleton";
import { ErrorBlock } from "@/components/states";
import { money, usePeriod } from "@/lib/period";

export function SourceSheet() {
  const { sourceId, openSource } = usePeriod();
  const id = sourceId ?? "";
  const q = useGetSource(id, { query: { enabled: !!id, queryKey: getGetSourceQueryKey(id) } });
  return (
    <Sheet open={!!sourceId} onOpenChange={(o) => !o && openSource(null)}>
      <SheetContent className="w-full sm:max-w-xl overflow-y-auto" data-testid="sheet-source">
        <SheetHeader>
          <div className="eyebrow">Source ledger</div>
          <SheetTitle className="font-mono text-base break-all" data-testid="text-source-id">Supporting source figures</SheetTitle>
          <SheetDescription>{q.data?.description ?? "Ledger records supporting this figure."}</SheetDescription>
        </SheetHeader>
        <div className="mt-5">
          {q.isLoading && <div className="space-y-2">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-7" />)}</div>}
          {q.isError && <ErrorBlock error={q.error} onRetry={() => q.refetch()} />}
          {q.data && q.data.records.length === 0 && <p className="text-sm text-muted-foreground">No ledger records attached to this source.</p>}
          {q.data && q.data.records.length > 0 && (
            <div className="border rounded-md overflow-hidden">
              <table className="w-full text-xs">
                <thead className="bg-muted text-muted-foreground">
                  <tr>{["Period", "Scenario", "Unit / Cost centre", "Account", "Amount"].map((h) => <th key={h} className={`px-2.5 py-2 font-medium ${h === "Amount" ? "text-right" : "text-left"}`}>{h}</th>)}</tr>
                </thead>
                <tbody>
                  {q.data.records.map((r, i) => (
                    <tr key={i} className="border-t" data-testid={`row-source-${i}`}>
                      <td className="px-2.5 py-1.5 num">{r.period}</td>
                      <td className="px-2.5 py-1.5">{r.scenario}</td>
                      <td className="px-2.5 py-1.5">{r.businessUnit}<div className="text-muted-foreground">{r.costCentre}</div></td>
                      <td className="px-2.5 py-1.5">{r.account}</td>
                      <td className="px-2.5 py-1.5 num text-right">{["Headcount", "Customer count"].includes(r.account) ? r.amount.toLocaleString() : money(r.amount)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot><tr className="border-t bg-muted/50 font-semibold"><td colSpan={5} className="px-2.5 py-2">{q.data.records.length} records · scenarios shown separately; do not sum across scenarios</td></tr></tfoot>
              </table>
            </div>
          )}
          <p className="text-[11px] text-muted-foreground mt-4">Seeded sample ledger data for demonstration. Not real company results.</p>
        </div>
      </SheetContent>
    </Sheet>
  );
}

export function Cite({ id, n }: { id: string; n?: number }) {
  const { openSource } = usePeriod();
  return (
    <button
      type="button"
      onClick={() => openSource(id)}
      title={`Open source ${id}`}
      className="inline-flex items-center align-baseline mx-0.5 px-1 rounded-sm text-[10px] font-mono font-medium bg-accent text-accent-foreground hover:bg-primary hover:text-primary-foreground transition-colors"
      data-testid={`button-cite-${id}`}
    >
      {n !== undefined ? `[${n}]` : "[Source]"}
    </button>
  );
}
