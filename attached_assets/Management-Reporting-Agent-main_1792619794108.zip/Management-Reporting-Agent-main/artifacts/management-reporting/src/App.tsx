import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { PeriodProvider } from '@/lib/period';
import { Shell } from '@/components/shell';
import { SourceSheet } from '@/components/source-sheet';
import Overview from '@/pages/overview';
import Variances from '@/pages/variances';
import CommentaryPage from '@/pages/commentary';
import Kpis from '@/pages/kpis';
import Packs from '@/pages/packs';
import Assistant from '@/pages/assistant';
import SettingsPage from '@/pages/settings';

const queryClient = new QueryClient({ defaultOptions: { queries: { staleTime: 30_000, refetchOnWindowFocus: false } } });

function Router() {
  return (
    <Shell>
      <RoutedErrorBoundary>
        <Switch>
          <Route path="/" component={Overview} />
          <Route path="/variances" component={Variances} />
          <Route path="/commentary" component={CommentaryPage} />
          <Route path="/kpis" component={Kpis} />
          <Route path="/packs" component={Packs} />
          <Route path="/assistant" component={Assistant} />
          <Route path="/settings" component={SettingsPage} />
          <Route component={NotFound} />
        </Switch>
      </RoutedErrorBoundary>
    </Shell>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <PeriodProvider>
          <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
            <Router />
          </WouterRouter>
          <SourceSheet />
        </PeriodProvider>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
