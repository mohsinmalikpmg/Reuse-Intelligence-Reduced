---
name: Frontend instrumentation
description: Preview instrumentation incompatibility with explicit generic JSX calls
---
Prefer inferred generic component arguments in JSX rather than explicit `<Component<Type> ... />`.

**Why:** The preview's instrumentation inserted attributes before the generic argument, causing Babel parsing to fail even though TypeScript accepted the original source.

**How to apply:** If preview logs show malformed attributes around generic JSX while typecheck passes, remove explicit JSX type arguments and use inference or typed wrapper components. Do not disable the preview tooling just to bypass it.
