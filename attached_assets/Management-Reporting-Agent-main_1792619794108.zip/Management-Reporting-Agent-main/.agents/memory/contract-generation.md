---
name: Contract generation
description: OpenAPI generator naming collision between path validators and query parameter interfaces
---
Check generated naming when one operation combines path parameters with query parameters.

**Why:** Orval can export the same OperationParams name for a Zod path validator and a TypeScript query interface. Its regenerated barrel re-adds wildcard exports, so manually removing the wildcard is not a durable fix.

**How to apply:** Avoid the name collision in the source contract or generator configuration, and regenerate. For binary pack exports, query arguments are documented in the operation description and handled explicitly by the download caller.
