# Management Reporting Agent

A corporate finance demonstration app for monthly performance commentary and management packs.

## Run & operate

- API workflow: `pnpm --filter @workspace/api-server run dev` — FastAPI/Uvicorn, workflow-supplied PORT.
- Web workflow: `pnpm --filter @workspace/management-reporting run dev` — React/Vite.
- API docs: `/api/docs`; health: `/api/healthz`.
- `pnpm --filter @workspace/api-spec run codegen` regenerates API clients.
- `pnpm --filter @workspace/management-reporting run typecheck` checks the frontend.
- Python dependencies: `pyproject.toml` and `uv.lock`.
- Optional secret: `OPENAI_API_KEY`; no key is required for template commentary.

## Structure

- `artifacts/api-server/finance/`: SQLite seed/model, financial aggregation, commentary, exports and FastAPI routes.
- `artifacts/management-reporting/src/`: frontend pages and components.
- `lib/api-spec/openapi.yaml`: frontend API contract.
- `README.md`: data model, reseed instructions, AI configuration, review rules and deployment limitations.

## Constraints

- Preserve the explicitly requested Python/FastAPI and SQLite stack.
- All data is illustrative. Actuals stop at September 2026; never present future actuals as zeros.
- Generated commentary is source-locked. AI may select database-backed facts but never generate unchecked figures.
- Do not silently replace saved commentary during regeneration.
- The shared demo has no authentication. It is not ready for confidential production finance data.
- SQLite is local; durable hosting needs persistence and backups before relying on review history.
