# FUSEBOX — Power Cube / Circuit Experience Kit

**FUSEBOX is the product. Power Cube is its mark. Cenovus Energy is its parent brand.**

Start with `FUSEBOX_Interactive_Circuit_Experience.html` (or the downloadable self-contained `FUSEBOX_Standalone_Prototype.html`). It includes three interactive views:

1. **Trace:** a focused schematic Library. Click or keyboard-select a node to reveal existing solutions, component provenance, and a reuse action. Expand the conventional list alternative if preferred.
2. **Connect & Energize:** click or drag Pattern clustering from the capability tray into Version B. On a valid connection, the block seats and emits a short localized spark. `Run Both` displays seeded, deterministic output differences; remove the block and rerun to see the attributed output disappear. Click a difference to view its source. Try the blocked Auto-approve step to see the non-sparking compatibility rejection.
3. **Converge:** animate a **preview** of three source products becoming one governed successor. It is *not* a production approval.

The design uses a separate, faithful corporate logo reference extracted from the Cenovus standards PDF provided by the team. Before release, replace with Cenovus's approved master artwork. Do not merge the parent logo into the FUSEBOX wordmark.

## Files

- `FUSEBOX_Standalone_Prototype.html`: fully offline, with the approved-style visual assets embedded (no local folders required).
- `FUSEBOX_Interactive_Circuit_Experience.html`: source HTML with local asset links; edit and run alongside `assets/`.
- `FUSEBOX_Editable_Circuit_Library.svg`: actual vector circuit, editable in Figma or other SVG tools.
- `FUSEBOX_Editable_Circuit_Library.png`: visual quick reference.
- `FUSEBOX_Weld_and_Energize_Motion.gif`: animated art-direction storyboard for the tactile connection and execution moments.
- `FUSEBOX_Schematic_Interaction_Design_Spec.md`: full design system, states, transitions, accessibility, event contracts, Replit integration mapping, Thursday build priorities and tests.
- `FUSEBOX_Copy_Paste_Replit_Implementation_Prompt.md`: focused, implementation-ready Replit instructions.
- `assets/`: product vector marks and the Cenovus official-logo reference, plus optional moodboard.

## What the prototype does not do

The HTML is **not connected to the current Replit backend**. Its output examples are produced by a deterministic local fixture to illustrate the intended UX. It does not persist votes, approvals or production data. The real app must use the existing backend execution, evidence persistence and governance gates. The CSS/SVG and JavaScript were syntax/asset checked; browser interaction QA was blocked by the restricted browser policy in this environment and should be run in Replit before the live demo.

**Motion design rule:** The spark confirms a *valid capability connection*; the energized trace reflects *actual execution*; convergence marks a *persisted governance outcome*. None should be used as decorative substitute for evidence.
