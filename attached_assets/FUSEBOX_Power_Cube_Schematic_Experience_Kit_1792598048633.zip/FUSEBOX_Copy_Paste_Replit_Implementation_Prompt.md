# Replit implementation prompt — FUSEBOX Circuit Experience

Modify the existing Cenovus FUSEBOX React application in place. Preserve all working routes, A/B backend execution, persisted cases and approval decisions. The product name is **FUSEBOX** and the chosen logo mark is **Power Cube**. It is NOT PowerCube as a product name. Use the supplied `assets/fusebox-logo-dark.svg` in the dark nav, `assets/fusebox-logo-light.svg` on light surfaces, and `assets/cenovus-energy-logo.png` in a separate endorsement region that follows Cenovus logo clear-space and sizing rules. Use the authentic master asset when provided by Cenovus.

## Design objective

Create a circuit-native, Apple-level tactile-feeling UX without adding clutter. Four verbs: **Trace / Connect / Energize / Converge**. Animation reinforces a real backend state change; it must not simulate execution success, evidence or approvals.

### P0: 1. Trace — optional schematic Library

- Retain current Library grid/list/search. Add a `View schematic` control. Default search remains simple, one recommendation plus up to two alternatives.
- For a selected business problem, display at most three solutions and four reusable capabilities in a dark navy technical-circuit view with clear orthogonal rounded traces. Use the existing catalogue data; do not hard-code new production claims.
- Clicking a node highlights its immediate connected paths and opens an inspector with: why this matches, source, certification, owner and `Try in Version B`. Keyboard access and list mode are mandatory.
- Search and requirement-entry contexts should run reuse matching before allowing a new capability to be generated; recommend existing options before creation.

### P0: 2. Connect — magnetic snap and localized weld

- In the current A/B Workbench, allow click-to-add and drag-and-drop into a Version B governed socket. A remains locked.
- On dragover, compatible sockets show slight 100–160ms alignment and a cyan/orange border. Incompatible ports remain dark and show a concise reason; never weld them.
- Validate compatibility using existing control/dependency/backend logic. Only after the backend confirms the new capability state should the block seat using a 260–380ms spring and a single localized 450–650ms electric weld spark. Display `Connected: <name> · source <solution>`.
- Mark prior A/B evidence stale immediately when Version B changes. Add one obvious `Undo` or remove action. No fake canvas blocks: inserted capabilities must execute.
- Do not use new AI feature generation as the default. The existing closest capability must be offered first. An experimental created step is permitted only as an explicit alternative and must be labelled experimental.

### P0: 3. Energize — real A/B output feedback

- Use the existing same-input A/B execution API, not synthetic projected benefits.
- On `Run both`, briefly illuminate the active path. Prefer actual backend progress events; if unavailable, show truthful indeterminate progress and reveal the completed trace after execution. Never imply a step has completed before the API confirms it.
- Then reveal A/B outputs in place and highlight only the changed lines/spans. Clicking a changed span shows the actual contributing step and source-solution provenance.
- Votes and metrics must be bound to the current input and Version B fingerprint, with repeat votes replaced rather than double counted.
- Default visible elements: shared input, A and B workflows, A and B outputs, top difference, preference action. Collapse metrics/traces/tester setup.

### P0: 4. Converge — govern before celebration

- Create a circuit convergence view previewing source products flowing into Power Cube and out to one governed successor.
- As a **preview**, label it illustrative. The genuine 700–1100ms convergence animation must only play after the owner and IT decisions have been saved and the successor/version exists in the Library with source-product disposition statuses.
- Do not automatically approve or retire products via animation.

## Required system design

- Base: Cenovus slate `#365860`, sienna `#C5683B`, green `#8A9A36`, light blue `#6E9EAF`. FUSEBOX extensions: electric navy `#071D27`, cyan `#64D8E8`, energetic orange `#FF963D`. Avoid full-page glow.
- Use Inter for UI; custom FUSEBOX SVG wordmark instead of a generic webfont fallback. 8px spacing grid, 12px block corners, 18–22px panel corners, generous whitespace.
- Every touch target at least 44×44px when practical; all drag interactions have button alternatives.
- Respect `prefers-reduced-motion`, pause animation for accessibility, no audio by default, and optional supported-device haptics only by user opt-in.
- Use `transform` and `opacity` for 60fps motion; avoid large shadows and perpetual pulses. Status changes must be announced as plain text and ARIA live messages.

## Accept only if end-to-end proof works

1. From a business problem in Library, user locates an existing capability and sees its provenance.
2. User adds it to B through click or drag. Compatible connection gets one weld; blocked control gets a reason and no weld.
3. User runs A and B on exactly the same input; actual executed B output changes; clicking diff identifies its source.
4. Removing the new capability makes the previous result stale; rerun removes its contribution.
5. Owner and IT approval are persisted before showing the real published-convergence state; Library and source-product states update accordingly.
6. With reduced motion enabled, no spark or moving trace is needed to understand the entire journey.

The supplied standalone HTML, SVG and GIF demonstrate visual style and behaviour only. They use deterministic illustrative input/output text. **Do not replace existing real execution or persistence with the prototype's seeded JavaScript.**
