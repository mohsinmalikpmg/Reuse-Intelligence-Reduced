# FUSEBOX — Circuit Experience Design System

## Product identity and visual thesis

**Product name:** FUSEBOX. **Primary product mark:** Power Cube. **Parent organization:** Cenovus Energy.

Power Cube is an icon and system motif, **not** a new product name. The full FUSEBOX wordmark must remain present in navigation and branded experiences. Cenovus's official logo is an independent endorsement, never altered, recreated with text, squeezed into the Power Cube, or attached to the FUSEBOX wordmark. The corporate logo shown here is extracted from the official standards the team supplied; replace with an approved master asset before production.

**Design promise:** *Trace what exists. Connect what matters. Prove what changed.*

**Signature experience:** A user sees the organizational knowledge landscape as an intelligible electrical circuit, finds an existing reusable capability, snaps it into a governed workflow, watches a brief electrical weld confirm compatibility, energizes A and B against the same input, and sees real output differences directly linked to the new connection. When approvals are complete, several source products visibly converge into one successor.

Do not make all the screens dark and glowing. The product shell remains quiet and legible, with a restrained FUSEBOX product identity. **The circuitry is the specialist instrument panel**, shown on demand in the Library or Workbench. Animation should be concentrated around purposeful milestones, not looping for atmosphere.

### Brand relationship

- Corporate brand: authentic Cenovus Energy mark at the top-right of the app, with independent clear space and a white placement field. Follow the supplied logo standards, including the complete ENERGY descriptor and minimum size.
- Product brand: Power Cube + bold FUSEBOX logotype at upper-left / persistent shell.
- Product signature: an electrical spark that appears at *a validated connection*, not everywhere.
- Visual inheritance: Cenovus slate `#365860`, sienna `#C5683B`, green `#8A9A36`, blue `#6E9EAF` and clay `#765948`.
- FUSEBOX extensions: conductive cyan `#64D8E8`, energized orange `#FF963D`, schematic navy `#071D27`. These extensions are app UI colours, **not** changes to Cenovus's official brand palette.

## Four experiential verbs

| Verb | Where | User action | Physical metaphor | Product meaning |
|---|---|---|---|---|
| **Trace** | Solution/capability Library | Search or select a node | Current follows compatible paths | Existing work is discoverable and attributable |
| **Connect** | Workbench | Drop a capability or select Add | Magnetism, snap, one short weld | A compatible change is actually added to Version B |
| **Energize** | A/B Workbench | Run Both | Power pulses propagate through executed blocks | Both versions were run against the same input |
| **Converge** | Owner/IT decision | Confirm persisted approval | Multiple source circuits resolve into one outlet | A governed successor/version is published; source disposition is recorded |

These are *functional metaphors*: each animation must correspond to a real, auditable application state transition.

## Schematic Library: meaningful graph, not a spaghetti map

### Presentation rule

Default Discover uses one recommended solution and at most two alternatives. **The circuitry view is optional and intentional**, accessed through `View schematic` or the Library view control. Do not make an expansive graph the default search result.

When opened, the circuit canvas starts focused on one business problem and its most relevant adjacent objects:

- **One problem** at left: the job being solved, described in Today/Better terms.
- **Up to three existing solutions** in the middle: certified base highlighted, alternatives secondary.
- **Up to four relevant reusable components** at right: source labels visible on selection.
- A persistent inspector with exactly one node selected. Technical details are hidden unless requested.

Include compact `All / Solutions / Components` filters; an always-visible switch to a conventional accessible list view; keyboard navigation; click-to-select, Enter to inspect, Esc to close drawers. Pan/zoom can be added later, but navigation must not depend on dragging, double-clicking or discovering hidden gestures.

### Schematic visual grammar

- **Rounded orthogonal traces**, 2px resting, 3px highlighted, 8px corner bends, never arbitrary decorative lines.
- **Connectors and ports:** circles of diameter 8–10px; illuminated only if active. Required locked controls have a lock glyph.
- **Nodes:** compact semi-opaque navy panels, 10–12px corner radius, left accent bar, one-line purpose and status.
- **Line encoding:** cyan = existing certified/reusable connection; sienna/orange = experimental or modification path; olive/green = validated/published; muted slate = inactive; red/orange warning = incompatible. Always pair colour with text/status.
- **Source/destination:** directed edges carry labels in the inspector: `solves`, `uses`, `derived from`, `superseded by`, `reused in`.
- **Trace animation:** only animate selected paths on user interaction, with a gentle single travel pulse; no ambient full-board flashing.
- **Disclosure:** click a node to focus its 1-hop neighbours. `See connections` reveals an additional hop. Do not load the entire enterprise portfolio into one view.
- **Limit:** 8 visible nodes on first focus, and no more than 15 after expanding a branch without collapsing others.

### Data semantics

Use a graph *view* over the existing structured catalogue; do not introduce a graph database for the hackathon. Minimum entities are `BusinessProblem`, `SolutionFamily`, `SolutionVersion`, `Capability`, `Configuration`, `Experiment` and `Requirement`. Do not conflate experimental steps with certified capabilities.

Illustrative graph:

```text
Recurring equipment issues (business problem)
  ├─ Work Order Triage       [certified base] → Summarizer [required]
  ├─ Pattern Finder          [pilot source]   → Pattern clustering [reusable]
  └─ Action Tracker          [source product] → Action tracking [reusable]

New safety requirement → Experimental safety step [not yet certified]
```

The safety item in this demo is an **illustrative experimental concept**, not a capability verified in the exported Replit catalogue. The real app should not label it certified or already reusable until the data supports that status.

## Connect: magnetic snap and weld

1. User clicks `+` between workflow steps or drags a Library capability to Version B.
2. **Before creation**, the system queries existing capabilities/experiments for overlapping functions and presents an existing option first.
3. While dragging, only compatible governed slots subtly glow. Incompatible targets stay neutral and say why.
4. On hover near a permitted slot: 80–120ms magnetic alignment / subtle 1.025 scale; port alignment becomes obvious.
5. On drop, validate input/output contract, dependencies, required human controls and capabilities' supported location.
6. **Only after the backend confirms insertion:** brief weld arc at the connection joint (450–650ms), node seats with a slightly overshooting spring, connecting wire becomes orange/energized. This is the key tactile moment.
7. Show plain-language feedback: `Pattern clustering connected to Version B · source: Pattern Finder`.
8. The baseline stays locked; Version B receives a new configuration fingerprint and prior comparisons become visibly stale.
9. Removing a step uses a quiet 150–220ms disconnect/retraction; never show a spark for removal or error.

A welding effect should never be used as a substitute for actual capability insertion. It is an acknowledgment of a completed, valid operation.

### Compatibility rejection

If an attempted step would bypass a mandatory human approval, the port does **not** illuminate or weld. The candidate returns smoothly to its original location and the interface says: `Not compatible: human review is required and cannot be bypassed.` Include a direct link to the locked control reason. Reject, don't dramatize.

## Energize: running A and B

- The command is `Run both` or, in the expressive workbench, `Energize A/B` paired with a play icon.
- Both routes receive the **same input**; A is locked. Highlight the actual selected input above both circuits.
- Pulse the active traces sequentially **only as genuine step state events arrive**. If the API only returns completion, show a truthful indeterminate `Running both workflows` state, then replay the recorded trace afterward. Never fabricate step timing or progress events.
- Trace status sequence: `queued → validating → running → completed/failed`. Display which step failed, with an ordinary error message and Retry action.
- On completion: dissipate the travel pulse, show a brief green check, and unfold A/B output columns at the same scroll location (avoid navigation jumps).
- **Causal diff:** highlight new, removed and changed output spans. Clicking the changed span highlights the exact contributing step and opens a source/provenance drawer.
- **Evidence rule:** claims about quality or accuracy only exist when labelled expected results or real human evaluations support them. A longer B output is not, by itself, an improvement.
- **Revision rule:** every B modification invalidates the latest displayed result/vote until a new same-input run completes. Any stale result is labelled `Earlier version`.
- Human preference choices: `A better / B better / Neither`. In the real app, vote records must be unique per tester + run pair and carry the exact experiment fingerprint.

## Converge: a rare milestone

Use the Power Cube as the **center of the convergence circuit**. Only after owner and IT approvals have been persisted and the Library successor created:

- The source solution traces draw inward to Power Cube over 500–800ms.
- A contained warm spark illuminates the cube; one output line turns green and flows to the governed successor.
- A clear message appears: `One governed product published`.
- Source products receive structured dispositions: `retain as base / reuse capability / fold / retire pending migration`.
- The schematic and ordinary Library both update to the new state.

This is a *one-time completion animation*, not a repetitive confetti celebration. Before real approval, the UI may offer `Preview convergence` with a conspicuous illustrative label, but must not pretend the merger has occurred.

## Motion tokens and interaction physics

| Motion | Duration | Easing | Sensory character |
|---|---:|---|---|
| Hover reveal / conductor highlight | 90–130ms | ease-out | Crisp, no wobble |
| Tap / press compression | 90ms down, 150ms release | ease-out | 0.985 scale, subtle shadow reduction |
| Magnetic alignment | 100–160ms | cubic-bezier(.18,1,.32,1) | Slides into alignment, no bounce yet |
| Snap into socket | 260–380ms | cubic-bezier(.18,1.35,.42,1) | Mild overshoot and settle |
| Welding flash and particles | 450–650ms | ease-out | One localized arc; never full-screen |
| Schematic path-trace emphasis | 250–420ms | ease-out | One clear conducting path |
| Actual execution current | Duration follows step state | linear for travelling glow | Moving signal implies real work |
| Output diff reveal | 240–360ms | ease-out | Existing text steady; only new evidence enters |
| Completion acknowledgement | 420–650ms | ease-out | Confident, restrained green check |
| Governed convergence | 700–1100ms | ease-out | Significant but not indulgent milestone |

Use CSS transforms and opacity for almost all animations. Avoid layout animation with top/left, large blurred canvases and full-screen video backgrounds. Preserve 60fps interactions on typical laptops; degrade gracefully under load.

### Micro-haptics

The web cannot guarantee actual haptic feedback on desktop browsers. **Design for visual tactility first**: press compression, controlled spring, single spark, sonic silence. Optional supported-device vibration may use `navigator.vibrate(12–18)` only with user action and an explicit opt-in; never claim that the effect will work universally. Do not enable audio by default.

### Motion safety and accessibility

- Honor `prefers-reduced-motion: reduce`. Replace travelling pulses and particle bursts with instant port-state changes, border emphasis, textual status and static diagrams.
- Do not use repeated flashing (>3 flashes/s) or full-screen blooms. Keep localized orange flashes under 650ms.
- Do not rely on colour alone: use the text `connected`, `experimental`, `validated`, `locked`, `failed` and `approved` alongside the wire state.
- Preserve keyboard actions: a module can be added by click; drag/drop is an accelerator, not a requirement.
- Provide visible focus rings and a non-schematic list fallback for screen readers.
- Announce successful connections, failures, and run completion through `aria-live` regions.
- Present progress truthfully: do not animate fake step completions if the API cannot report them.

## Layout and product-level craft

**FUSEBOX visual identity:** Electric Ink (`#071D27`) is the technical canvas and app chrome, while Cenovus slate (`#365860`) grounds navigation and normal actions. Cards and input panels use clean whites/neutrals with predictable depth. Glows belong to active ports, connections and intentional milestones, not static card shadows.

- App shell navigation: 224px desktop, icon rail near 70px tablet, concise mobile nav.
- Content max-width: 1720px; ideal primary interaction width 1100–1450px.
- Grid base: 8px. Spacing tokens: 4, 8, 12, 16, 24, 32, 48px.
- Control corners: 10–12px; card corners: 16–22px; circuit blocks: 10–12px. Power Cube itself is faceted, distinct from UI cards.
- Typical text: 13–15px; secondary labels 10–12px minimum; headings 34–52px only on top-level page entry. Do not shrink critical workflow step labels below legibility.
- Typography: Inter for product UI, a geometric display face such as Sora for editorial headings if licensed/available; FUSEBOX wordmark stays its custom vector artwork. Do not recreate the wordmark with arbitrary text on final screens.
- Subtle panel shadows only, 1px light borders, ample negative space. Dark schematic background grid: 24px, line opacity below 10%.
- Maximum default cognitive payload: one primary CTA, three choices, one warning, one visible recommendation; more on demand.

## Recommended screen architecture

**Discover:** calm white. Today → Better, immediate recommendation. Schematic view available as a small secondary control.

**Library / Trace:** circuit map on dark technical canvas, one focused branch; right inspector. Toggle between cards/list and schematic. Search filters and highlights paths without expanding the entire graph.

**Workbench / Connect:** familiar A/B pair with white controls around the dark circuit viewport. Source tray shows 2–3 recommended modules before any `Create new` action.

**Test / Energize:** same screen and scroll position. User sees the circuit pulse and then A/B outputs with clickable provenance. The visual glow must not be mistaken for a test-score benefit.

**Owner / Review:** normal white decision interface, little or no sparking. Show one grouped improvement, linked experiments and current evidence.

**IT / Converge:** before approval, a subdued schematic preview. On persisted approval, the convergence visual resolves. Approved and retired product states update immediately across the Library.

## Integration into current Replit implementation

Do not replace the existing real A/B engine with this visual prototype. Use this as a **front-end interaction layer** over the existing working source.

| Existing file / area | Integrate |
|---|---|
| `artifacts/workbench/src/components/frame.tsx` | Swap to FUSEBOX Power Cube wordmark and official Cenovus logo in a separate endorsement zone; apply concise navigation, page transitions |
| `artifacts/workbench/src/index.css` | Add official-derived colour tokens, distinct FUSEBOX electrical accents, spacing, reduced-motion and focus tokens |
| `artifacts/workbench/src/pages/library.tsx` | Add `Schematic view` toggle while retaining list/grid for accessibility and broad search |
| `artifacts/workbench/src/components/library-tree.tsx` | Reuse structured relationships as an orthogonal circuit schematic with progressive disclosure |
| `artifacts/workbench/src/pages/workbench.tsx` | Add click/drag socket, compatibility status, and brief weld confirmation **after saved state succeeds** |
| `artifacts/workbench/src/components/flow.tsx` | Port, connector and active step styles; preserve locked required steps |
| `artifacts/workbench/src/components/wb-compare.tsx` | Energize/run microfeedback, clickable causal diffs, non-fabricated result display and vote state |
| `artifacts/api-server/src/lib/configuration.ts` | Return compatibility, required control and source-of-capability reasons on add/edit |
| `artifacts/api-server/src/lib/workbench.ts` | Continue real same-input A/B execution; include execution step events if feasible; otherwise replay completed trace, never fake live progress |
| `artifacts/api-server/src/lib/matching.ts` | Reuse-first recommendations before new-step generation; explainable contextual matches |
| `artifacts/workbench/src/pages/portfolio.tsx` | Animate convergence only after backend-confirmed owner/IT lifecycle transition and persisted Library successor |

No enterprise graph database, custom GPU shaders, extra production builder or audio asset is necessary. CSS + SVG + existing React state and API routes are sufficient for the Thursday demonstration.

### Candidate React event contract

```ts
// State drives visuals. Animation never drives business state.
type CircuitUXEvent =
  | { type: 'capability-dragging'; capabilityId: string; targetSlot: string }
  | { type: 'capability-rejected'; capabilityId: string; reason: string }
  | { type: 'capability-connected'; capabilityId: string; sourceSolutionId: string; newFingerprint: string }
  | { type: 'ab-run-started'; inputId: string; aVersion: string; bFingerprint: string }
  | { type: 'step-started'; runId: string; stepId: string }
  | { type: 'step-completed'; runId: string; stepId: string }
  | { type: 'step-failed'; runId: string; stepId: string; message: string }
  | { type: 'ab-run-completed'; runId: string; sameInputVerified: true; diffIds: string[] }
  | { type: 'consolidation-approved'; successorId: string; persisted: true };
```

Do not use a `capability-connected` event until the server has confirmed the change. Do not issue `step-completed` events from a decorative timer. Do not issue `consolidation-approved` until the server has persisted the result.

## Thursday-focused build order

**P0 — Highest perceptual and business return**
1. Apply FUSEBOX + Power Cube product branding, with separate official Cenovus logo.
2. Add an optional Circuit Library view for the current seeded business problem.
3. Add reusable capability socket + click/drag-to-connect + validation outcome, with a single localized weld effect.
4. Use the real workbench run endpoint for Energize, displaying A and B actual outputs; highlight source-attributed changes and stale revisions.
5. Gate final convergence animation behind real persisted approvals (or label preview explicitly).

**P1 — Polish**
- Magnetic proximity and spring timing.
- Source-to-output trace on click.
- Crossfade between focused Library branches.
- Offline/reduced-motion and tablet verification.

**Do not do before Thursday**
- Full-screen neon motion at all times.
- Real-time physics simulation, audible zapping, or shader-heavy effects.
- Every enterprise solution displayed as a giant schematic.
- Animated proof before a real run has finished.
- A separate product name such as PowerCube or Powercube.

## Acceptance tests

1. Header clearly reads FUSEBOX, with Power Cube icon; authentic Cenovus Energy appears separately and unaltered.
2. User can find an existing component from a problem via the Library schematic in two interactions or fewer.
3. Circuit view supports click and keyboard selection, provenance inspection and a non-graph alternative.
4. Adding a permitted capability updates Version B and triggers one short connection animation only after confirmation.
5. Incompatible capability never welds and gives a specific reason.
6. Removing a capability disconnects quietly and invalidates previous B result evidence.
7. Run Both sends exactly the same input to A and B. When complete, the outputs reflect actual executed workflow configurations.
8. Click on changed output reveals the responsible step and originating solution.
9. Reduced motion turns off pulses/sparks while preserving all information.
10. Convergence does not appear approved until owner and IT decisions and successor state are actually persisted.

### Demonstration prototype limitations

`Fusebox_Circuit_Experience.html` is an interactive art-direction and microinteraction prototype. It uses **illustrative seeded text** and deterministic JavaScript branching rather than the real Replit execution engine. Its preferred-state and governance actions are local previews; they do **not** write to the real Fusebox database. Treat it as a high-fidelity design handoff, not as evidence of implemented production functionality.
