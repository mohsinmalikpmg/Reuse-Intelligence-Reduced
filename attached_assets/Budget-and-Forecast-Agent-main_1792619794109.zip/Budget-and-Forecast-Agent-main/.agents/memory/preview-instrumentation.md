---
name: Preview instrumentation compatibility
description: Generic JSX type arguments can break the preview despite a passing typecheck
---
Prefer inferred component generics over explicit JSX type arguments with the preview instrumentation.

**Why:** The cartographer transform inserted metadata between a component name and its generic type argument, producing invalid JSX for Babel even though TypeScript passed.

**How to apply:** For generic components, infer the type from typed props instead of writing explicit generic arguments in JSX. A passing typecheck alone does not detect this transformed-source error.
