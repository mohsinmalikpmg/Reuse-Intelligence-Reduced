---
name: Generated client compatibility
description: TypeScript environment requirement for Orval-generated mutation headers
---
Keep DOM.Iterable enabled for the generated React API client.

**Why:** The installed Orval emits `Headers.entries()` for mutation requests; a DOM-only library configuration fails during codegen's chained typecheck despite valid generated code.

**How to apply:** If updating the client generator or rebuilding TypeScript configuration, preserve iterable DOM typings instead of modifying generated output.
