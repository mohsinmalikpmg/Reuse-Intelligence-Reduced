"""LLM selects an allowlisted analysis; all numbers and wording are server rendered."""
import json
import os
from collections import defaultdict
from .data import rows, settings, CENTRES
from .calculations import aggregate


def answer(message):
    text = message.lower()
    intent = ("versions" if any(w in text for w in ["q2", "q3", "changed", "version"]) else
              "contractors" if "contractor" in text else
              "revenue" if "revenue" in text else
              "quarter" if "quarter" in text else
              "risks" if any(w in text for w in ["exceed", "risk", "over", "budget"]) else "unsupported")
    mode = "Rule-based"
    if os.environ.get("OPENAI_API_KEY"):
        try:
            from openai import OpenAI
            client = OpenAI(timeout=20, max_retries=0)
            completion = client.chat.completions.create(
                model="gpt-4o-mini", temperature=0,
                messages=[
                    {"role": "system", "content": 'Classify finance questions. Return JSON {"intent": one of "versions","contractors","revenue","quarter","risks","unsupported"}. versions=Q2 vs Q3; contractors=contractor run rate and OpEx; quarter=cost centres exceeding budget this quarter; risks=full-year cost overruns; revenue=revenue vs plan. Do not calculate or return numbers.'},
                    {"role": "user", "content": message}],
                response_format={"type": "json_object"})
            chosen = json.loads(completion.choices[0].message.content)["intent"]
            if chosen in ("versions", "contractors", "revenue", "quarter", "risks", "unsupported"):
                intent = chosen
                mode = "OpenAI-assisted · verified calculations"
        except Exception:
            mode = "Rule-based · OpenAI unavailable"
    data = rows()
    # Explicit BU or cost centre mentions scope the evidence, using known names only.
    matches = [cc for centres in CENTRES.values() for cc in centres if cc.lower() in text]
    units = [bu for bu in CENTRES if bu.lower() in text]
    if matches:
        data = [r for r in data if r["costCentre"] in matches]
    elif units:
        data = [r for r in data if r["businessUnit"] in units]
    evidence = []
    if intent == "versions":
        evidence = aggregate([r for r in data if r["account"] not in ("Revenue", "COGS")], budget="q2")
        change = sum(r["variance"] for r in evidence)
        summary = f"Full-year OpEx in Q3 is ${change:,.2f} {'higher' if change >= 0 else 'lower'} than Q2 (signed change). Technology contractor costs and the rescheduling of marketing spend are likely drivers; inspect account-level variances to validate."
        calc = "SUM(forecast.amount WHERE version='Q3 Forecast') − SUM(forecast.amount WHERE version='Q2 Forecast'), Jan–Dec 2026, excluding Revenue and COGS. Evidence budget column = Q2; value = Q3."
    elif intent == "contractors":
        contractors = [r for r in data if r["account"] == "Contractors"]
        by_cc = defaultdict(list)
        for r in contractors:
            by_cc[r["costCentre"]].append(r)
        for cc, group in by_cc.items():
            ytd = sum(r["actual"] or 0 for r in group)
            recent = sum(r["actual"] or 0 for r in group if 7 <= r["month"] <= 9)
            value = ytd + recent
            baseline = sum(r["q3"] for r in group)
            evidence.append(dict(label=cc, budget=round(baseline, 2), value=round(value, 2),
                                 variance=round(value-baseline, 2), driver="run-rate"))
        delta = sum(r["variance"] for r in evidence)
        base = sum(r["q3"] for r in data if r["account"] not in ("Revenue", "COGS"))
        summary = f"If contractor spend continues at the Jul–Sep monthly average, full-year OpEx would be ${base+delta:,.2f}, a signed change of ${delta:,.2f} versus Q3. All other accounts remain at Q3 forecast."
        calc = "Contractor projection = SUM(Jan–Sep actuals) + 3 × SUM(Jul–Sep actuals)/3. OpEx impact = projected contractors − Q3 contractors. Evidence budget = Q3 contractors; value = projected contractors."
    elif intent == "revenue":
        evidence = aggregate([r for r in data if r["account"] == "Revenue"])
        delta = sum(r["variance"] for r in evidence)
        summary = f"Full-year revenue is ${sum(r['value'] for r in evidence):,.2f}, a signed variance of ${delta:,.2f} versus budget. Lower revenue is unfavourable."
        calc = "SUM(Q3 Forecast revenue) − SUM(budget revenue), Jan–Dec 2026, grouped by business unit."
    elif intent in ("risks", "quarter"):
        subset = [r for r in data if r["account"] not in ("Revenue", "COGS") and (intent != "quarter" or r["month"] >= 10)]
        groups = aggregate(subset, "costCentre")
        limits = settings()
        evidence = [r for r in groups if r["variance"] > 0 and (
            r["variance"] > limits["dollarThreshold"] or
            (r["variance"]/r["budget"]*100 if r["budget"] else 100) > limits["percentThreshold"])]
        evidence.sort(key=lambda r: r["variance"], reverse=True)
        for item in evidence:
            drivers = aggregate([r for r in subset if r["costCentre"] == item["label"]], "account")
            driver = max(drivers, key=lambda r: r["variance"])
            item["driver"] = f'{driver["label"]} · {driver["driver"]}'
        period = "Q4 (Oct–Dec 2026)" if intent == "quarter" else "FY2026"
        summary = f"{len(evidence)} cost centres exceed the configured OpEx threshold in {period}. Flagged adverse variance totals ${sum(r['variance'] for r in evidence):,.2f}. Driver tags are rule-based indications, not confirmed causes."
        calc = f"SUM(Q3 Forecast OpEx) − SUM(budget OpEx), {period}, grouped by cost centre. Flag if positive variance exceeds {limits['percentThreshold']:g}% OR ${limits['dollarThreshold']:,.2f}. Reporting cutoff: September 30, 2026."
    else:
        summary = "I can provide verified cost-centre budget risks, Q4 overruns, contractor run-rate impact, revenue vs plan, and Q2-to-Q3 changes. Please ask about one of these analyses; I won't estimate unsupported figures."
        calc = "No calculation performed. Supported analyses query the SQLite budget, actuals and forecast tables."
    return dict(answer=summary, mode=mode, calculation=calc, evidence=evidence)
