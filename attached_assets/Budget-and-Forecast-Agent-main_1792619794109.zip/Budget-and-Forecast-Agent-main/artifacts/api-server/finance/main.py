import csv
import io
import os
from contextlib import asynccontextmanager
from typing import Literal
from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import Response
from pydantic import BaseModel, Field, ConfigDict, field_validator
from .data import initialize, rows, settings, connect, ACCOUNTS
from .calculations import project, aggregate
from .assistant import answer


@asynccontextmanager
async def lifespan(app):
    initialize()
    yield


app = FastAPI(title="Budget & Forecast Agent", lifespan=lifespan)


class Input(BaseModel):
    model_config = ConfigDict(allow_inf_nan=False, extra="forbid")


class Settings(Input):
    percentThreshold: float = Field(ge=0, le=100000)
    dollarThreshold: float = Field(ge=0, le=1e12)


class Scenario(Input):
    method: Literal["forecast", "ytd", "last3"]
    revenueGrowth: float = Field(ge=-100, le=1000)
    headcountCost: float = Field(ge=-100, le=1000)
    account: str
    accountAdjustment: float = Field(ge=-1e12, le=1e12)

    @field_validator("account")
    @classmethod
    def valid_account(cls, value):
        if value not in ACCOUNTS and value not in ("", "None"):
            raise ValueError("Unknown account")
        return value


class RiskInput(Input):
    title: str = Field(min_length=1, max_length=200)
    description: str = Field(max_length=5000)
    type: Literal["Risk", "Opportunity"]
    costCentre: str = Field(max_length=200)
    owner: str = Field(max_length=200)
    impact: float = Field(ge=0, le=1e12)
    status: Literal["Open", "Mitigating", "Closed"]

    @field_validator("title")
    @classmethod
    def valid_title(cls, value):
        if not value.strip():
            raise ValueError("Title is required")
        return value.strip()


class ChatInput(Input):
    message: str = Field(min_length=1, max_length=2000)


@app.get("/api/healthz")
def health():
    return {"status": "ok"}


@app.get("/api/finance")
def finance():
    return dict(rows=rows(), settings=settings(), fiscalYear=2026, actualThroughMonth=9,
                assistantMode="OpenAI-assisted" if os.environ.get("OPENAI_API_KEY") else "Rule-based")


@app.put("/api/settings")
def save_settings(data: Settings):
    with connect() as db:
        db.execute("UPDATE settings SET percent_threshold=?, dollar_threshold=? WHERE id=1",
                   (data.percentThreshold, data.dollarThreshold))
    return data


@app.post("/api/projection")
def projection(data: Scenario):
    if data.accountAdjustment and data.account in ("", "None"):
        raise HTTPException(422, "Choose an account for the dollar adjustment")
    return project(data)


@app.get("/api/risks")
def risks():
    with connect() as db:
        return [dict(r) for r in db.execute("SELECT * FROM risks ORDER BY impact DESC,id")]


@app.post("/api/risks")
def create_risk(data: RiskInput):
    d = data.model_dump()
    with connect() as db:
        cursor = db.execute("""INSERT INTO risks(title,description,type,costCentre,owner,impact,status,source)
          VALUES(:title,:description,:type,:costCentre,:owner,:impact,:status,'Manual')""", d)
        return dict(d, id=cursor.lastrowid, source="Manual")


@app.put("/api/risks/{id}")
def update_risk(id: int, data: RiskInput):
    d = dict(data.model_dump(), id=id)
    with connect() as db:
        if not db.execute("SELECT id FROM risks WHERE id=?", (id,)).fetchone():
            raise HTTPException(404, "Risk not found")
        db.execute("""UPDATE risks SET title=:title,description=:description,type=:type,costCentre=:costCentre,
          owner=:owner,impact=:impact,status=:status WHERE id=:id""", d)
        return dict(db.execute("SELECT * FROM risks WHERE id=?", (id,)).fetchone())


@app.delete("/api/risks/{id}")
def delete_risk(id: int):
    with connect() as db:
        if not db.execute("DELETE FROM risks WHERE id=?", (id,)).rowcount:
            raise HTTPException(404, "Risk not found")
    return {"status": "deleted"}


@app.post("/api/chat")
def chat(data: ChatInput):
    return answer(data.message)


@app.get("/api/export/{kind}")
def export(kind: Literal["landing", "risks"], format: Literal["csv", "xlsx"] = Query("csv")):
    if kind == "risks":
        records = risks()
        headers = ["id", "title", "description", "type", "costCentre", "owner", "impact", "status", "source"]
    else:
        records = aggregate([r for r in rows() if r["account"] not in ("Revenue", "COGS")])
        records = [dict(businessUnit=r["label"], budget=r["budget"], forecast=r["value"],
                        variance=r["variance"], variancePercent=round(100*r["variance"]/r["budget"], 2),
                        metric="OpEx (excludes COGS)", version="Q3 Forecast", fiscalYear=2026) for r in records]
        headers = ["businessUnit", "budget", "forecast", "variance", "variancePercent", "metric", "version", "fiscalYear"]
    def safe(v):
        # Prevent spreadsheet formula injection from free-text register fields.
        return "'" + v if isinstance(v, str) and v.lstrip().startswith(("=", "+", "-", "@", "\t", "\r")) else v
    values = [[safe(r.get(h, "")) for h in headers] for r in records]
    if format == "csv":
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(headers)
        writer.writerows(values)
        content = ("\ufeff" + buf.getvalue()).encode("utf-8")
        mime = "text/csv"
    else:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill
        wb = Workbook()
        ws = wb.active
        ws.title = kind.title()
        ws.append(headers)
        for row in values:
            ws.append(row)
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        for cell in ws[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="172D4A")
        for col in ws.columns:
            ws.column_dimensions[col[0].column_letter].width = min(60, max(18, max(len(str(c.value or "")) for c in col)+2))
            if col[0].value in ("impact", "budget", "forecast", "variance"):
                for cell in col[1:]:
                    cell.number_format = '"$"#,##0.00;[Red]("$"#,##0.00)'
        buf = io.BytesIO()
        wb.save(buf)
        content = buf.getvalue()
        mime = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    return Response(content, media_type=mime, headers={"Content-Disposition": f'attachment; filename="{kind}-2026.{format}"'})
