#!/bin/sh
set -eu
cd "$(dirname "$0")/../.."
exec uv run uvicorn finance.main:app --app-dir artifacts/api-server --host 0.0.0.0 --port "${PORT:?PORT is required}"
