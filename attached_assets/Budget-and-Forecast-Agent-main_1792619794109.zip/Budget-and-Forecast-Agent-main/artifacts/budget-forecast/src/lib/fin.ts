import type { FinancialRow, Settings } from "@workspace/api-client-react";

export const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export type Version = "q3" | "q2";
export const VERSION_LABEL: Record<Version, string> = { q3: "Q3 Forecast", q2: "Q2 Forecast" };

export const isRevenue = (account: string) => /revenue|sales income/i.test(account);
export const isCogs = (account: string) => /cogs|cost of (goods|sales)/i.test(account);
export const isOpex = (account: string) => !isRevenue(account) && !isCogs(account);

/** Favourable variance: positive = favourable. */
export function favVar(account: string, budget: number, value: number) {
  return isRevenue(account) ? value - budget : budget - value;
}

const fmt0 = new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 });
export function money(v: number | null | undefined, opts: { signed?: boolean } = {}) {
  if (v == null || Number.isNaN(v)) return "—";
  const a = fmt0.format(Math.abs(Math.round(v)));
  if (v < 0) return `(${a})`;
  return opts.signed && v > 0 ? `+${a}` : a;
}
export function compact(v: number) {
  const a = Math.abs(v);
  const s = a >= 1e6 ? `${(a / 1e6).toFixed(2)}M` : a >= 1e3 ? `${(a / 1e3).toFixed(1)}K` : a.toFixed(0);
  return `${v < 0 ? "-" : ""}$${s}`;
}
export function pct(v: number | null | undefined) {
  if (v == null || !Number.isFinite(v)) return "—";
  return `${v > 0 ? "+" : ""}${v.toFixed(1)}%`;
}
export const toneClass = (v: number) => (v > 0.5 ? "fav" : v < -0.5 ? "unfav" : "text-muted-foreground");

export interface Agg { budget: number; actual: number; q2: number; q3: number; ytdBudget: number; fyBudget: number }

export function landing(r: FinancialRow, v: Version) {
  return v === "q3" ? r.q3 : r.q2;
}

export interface Line { key: string; account: string; ytdBudget: number; ytdActual: number; fyBudget: number; fyLanding: number }

/** Group rows by key fn, with favourability computed against the account sign. */
export function groupLines(rows: FinancialRow[], through: number, v: Version, keyFn: (r: FinancialRow) => string) {
  const m = new Map<string, Line & { fav: { ytd: number; fy: number } }>();
  for (const r of rows) {
    const k = keyFn(r);
    let g = m.get(k);
    if (!g) { g = { key: k, account: r.account, ytdBudget: 0, ytdActual: 0, fyBudget: 0, fyLanding: 0, fav: { ytd: 0, fy: 0 } }; m.set(k, g); }
    if (r.month <= through) {
      g.ytdBudget += r.budget;
      g.ytdActual += r.actual ?? 0;
      g.fav.ytd += favVar(r.account, r.budget, r.actual ?? 0);
    }
    g.fyBudget += r.budget;
    g.fyLanding += landing(r, v);
    g.fav.fy += favVar(r.account, r.budget, landing(r, v));
  }
  return [...m.values()];
}

export function pnl(rows: FinancialRow[], pick: (r: FinancialRow) => number) {
  let revenue = 0, cogs = 0, opex = 0;
  for (const r of rows) {
    const x = pick(r);
    if (isRevenue(r.account)) revenue += x; else if (isCogs(r.account)) cogs += x; else opex += x;
  }
  return { revenue, cogs, opex, profit: revenue - cogs - opex };
}

/** Full-year forecast OpEx overrun, consistent with the assistant and thresholds. */
export function centreFlags(rows: FinancialRow[], _through: number, s: Settings, version: Version = "q3") {
  const m = new Map<string, { bu: string; centre: string; budget: number; actual: number }>();
  for (const r of rows) {
    if (!isOpex(r.account)) continue;
    const k = `${r.businessUnit}|${r.costCentre}`;
    const g = m.get(k) ?? { bu: r.businessUnit, centre: r.costCentre, budget: 0, actual: 0 };
    g.budget += r.budget; g.actual += landing(r, version); m.set(k, g);
  }
  return [...m.values()].map((g) => {
    const over = g.actual - g.budget;
    const overPct = g.budget ? (over / g.budget) * 100 : over > 0 ? 100 : 0;
    const flagged = over > 0 && (overPct > s.percentThreshold || over > s.dollarThreshold);
    return { ...g, over, overPct, flagged, reason: !flagged ? "" : overPct > s.percentThreshold && over > s.dollarThreshold ? "% and $" : overPct > s.percentThreshold ? "% threshold" : "$ threshold" };
  }).sort((a, b) => b.over - a.over);
}

export const uniq = (xs: string[]) => [...new Set(xs)].sort();

export function apiErr(e: unknown) {
  if (e && typeof e === "object") {
    const any = e as { data?: { error?: string; message?: string }; message?: string };
    return any.data?.error ?? any.data?.message ?? any.message ?? "Request failed";
  }
  return "Request failed";
}
