import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useGetFinance, useSaveSettings, getGetFinanceQueryKey } from "@workspace/api-client-react";
import { Page, Panel, LoadingBlock, ErrorBlock } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiErr, centreFlags, money } from "@/lib/fin";

export default function SettingsPage() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data, isLoading, error, refetch } = useGetFinance();
  const save = useSaveSettings();
  const [p, setP] = useState(""); const [d, setD] = useState("");
  const [init, setInit] = useState(false);
  useEffect(() => { if (data && !init) { setP(String(data.settings.percentThreshold)); setD(String(data.settings.dollarThreshold)); setInit(true); } }, [data, init]);

  const pn = Number(p), dn = Number(d);
  const valid = p !== "" && d !== "" && Number.isFinite(pn) && Number.isFinite(dn) && pn >= 0 && dn >= 0;
  const preview = data && valid ? centreFlags(data.rows, data.actualThroughMonth, { percentThreshold: pn, dollarThreshold: dn }).filter((f) => f.flagged).length : null;

  const submit = () => save.mutate({ data: { percentThreshold: pn, dollarThreshold: dn } }, {
    onSuccess: (s) => { qc.invalidateQueries({ queryKey: getGetFinanceQueryKey() }); setP(String(s.percentThreshold)); setD(String(s.dollarThreshold)); toast({ title: "Thresholds saved" }); },
    onError: (e) => toast({ title: "Save failed", description: apiErr(e), variant: "destructive" }),
  });

  return (
    <Page eyebrow="Configuration" title="Exception thresholds">
      {isLoading ? <LoadingBlock /> : error || !data ? <ErrorBlock error={error} onRetry={() => refetch()} /> : (
        <div className="max-w-2xl">
          <Panel title="Cost centre overrun flag" note="A centre is flagged when full-year Q3 forecast OpEx overrun exceeds the percent threshold OR the dollar threshold.">
            <form className="p-5 space-y-5" onSubmit={(e) => { e.preventDefault(); if (valid) submit(); }}>
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-1.5"><Label className="eyebrow">Percent threshold (%)</Label><Input className="num" type="number" min={0} step="0.1" value={p} onChange={(e) => setP(e.target.value)} data-testid="input-percent-threshold" /></div>
                <div className="space-y-1.5"><Label className="eyebrow">Dollar threshold ($)</Label><Input className="num" type="number" min={0} step="100" value={d} onChange={(e) => setD(e.target.value)} data-testid="input-dollar-threshold" /></div>
              </div>
              {!valid && <p className="text-[12px] text-destructive">Both thresholds must be non-negative numbers.</p>}
              <div className="flex items-center justify-between border-t border-border pt-4">
                <p className="text-[12px] text-muted-foreground" data-testid="text-flag-preview">
                  Saved: {data.settings.percentThreshold}% / ${money(data.settings.dollarThreshold)}
                  {preview != null && <> · would flag <span className="num font-semibold text-foreground">{preview}</span> centres</>}
                </p>
                <Button type="submit" disabled={!valid || save.isPending} data-testid="button-save-settings">{save.isPending ? "Saving…" : "Save thresholds"}</Button>
              </div>
            </form>
          </Panel>
        </div>
      )}
    </Page>
  );
}
