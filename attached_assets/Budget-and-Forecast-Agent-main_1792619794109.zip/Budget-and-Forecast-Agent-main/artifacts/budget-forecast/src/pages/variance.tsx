import { useMemo, useState } from "react";
import { useGetFinance, type FinancialRow } from "@workspace/api-client-react";
import { ChevronRight } from "lucide-react";
import { Page, Panel, LoadingBlock, ErrorBlock, Seg } from "@/components/shell";
import { MONTHS, VERSION_LABEL, type Version, money, pct, toneClass, groupLines, landing, favVar } from "@/lib/fin";

type Level = "businessUnit" | "costCentre" | "account" | "month";
const LEVELS: Level[] = ["businessUnit", "costCentre", "account", "month"];
const LABEL: Record<Level, string> = { businessUnit: "Business unit", costCentre: "Cost centre", account: "Account", month: "Month" };

export default function Variance() {
  const { data, isLoading, error, refetch } = useGetFinance();
  const [path, setPath] = useState<string[]>([]);
  const [ver, setVer] = useState<Version>("q3");
  const level = LEVELS[path.length];

  const view = useMemo(() => {
    if (!data) return null;
    const t = data.actualThroughMonth;
    let rows: FinancialRow[] = data.rows;
    path.forEach((p, i) => { const k = LEVELS[i] as Exclude<Level, "month">; rows = rows.filter((r) => r[k] === p); });
    if (level === "month") {
      return { t, month: true as const, rows: [...rows].sort((a, b) => a.month - b.month) };
    }
    const lines = groupLines(rows, t, ver, (r) => r[level as Exclude<Level, "month">]).sort((a, b) => a.fav.ytd - b.fav.ytd);
    return { t, month: false as const, lines };
  }, [data, path, ver, level]);

  return (
    <Page eyebrow="Variance analysis" title="Drill-down: business unit → centre → account → month"
      actions={<Seg value={ver} onChange={setVer} testid="toggle-version" options={[{ value: "q3", label: "Q3 Fcst" }, { value: "q2", label: "Q2 Fcst" }]} />}>
      <nav className="flex flex-wrap items-center gap-1 text-[12.5px] mb-4" data-testid="nav-breadcrumb">
        <button onClick={() => setPath([])} className={`px-2 py-1 rounded hover:bg-accent ${path.length === 0 ? "font-semibold text-primary" : "text-muted-foreground"}`} data-testid="button-crumb-root">All units</button>
        {path.map((p, i) => (
          <span key={i} className="flex items-center gap-1">
            <ChevronRight className="h-3.5 w-3.5 text-muted-foreground" />
            <button onClick={() => setPath(path.slice(0, i + 1))} className={`px-2 py-1 rounded hover:bg-accent ${i === path.length - 1 ? "font-semibold text-primary" : "text-muted-foreground"}`} data-testid={`button-crumb-${i}`}>
              <span className="text-[10px] uppercase tracking-wider text-muted-foreground mr-1">{LABEL[LEVELS[i]]}</span>{p}
            </button>
          </span>
        ))}
      </nav>
      {isLoading ? <LoadingBlock /> : error || !view ? <ErrorBlock error={error} onRetry={() => refetch()} /> : (
        <Panel key={path.join("/")} title={`By ${LABEL[level].toLowerCase()}`} note={view.month ? "Monthly detail. Actuals blank after close." : "Click a row to drill down. Sorted most unfavourable YTD first."}>
          <div className="overflow-auto">
            {view.month ? (
              <table className="ledger" data-testid="table-variance-month">
                <thead><tr><th>Month</th><th>Driver</th><th className="r">Budget</th><th className="r">Actual</th><th className="r">Q2</th><th className="r">Q3</th><th className="r">Var (Act / {ver.toUpperCase()})</th><th className="r">Var %</th></tr></thead>
                <tbody>
                  {view.rows.map((r, i) => {
                    const val = r.actual ?? landing(r, ver); const v = favVar(r.account, r.budget, val);
                    return (
                      <tr key={i} data-testid={`row-month-${r.month}`}>
                        <td>{MONTHS[r.month - 1]} {r.actual == null && <span className="text-[10px] text-muted-foreground ml-1">fcst</span>}</td>
                        <td className="text-muted-foreground max-w-[320px] truncate" title={r.driver}>{r.driver}</td>
                        <td className="r num">{money(r.budget)}</td><td className="r num">{money(r.actual)}</td><td className="r num">{money(r.q2)}</td><td className="r num">{money(r.q3)}</td>
                        <td className={`r num ${toneClass(v)}`}>{money(v, { signed: true })}</td><td className={`r num ${toneClass(v)}`}>{pct(r.budget ? (v / r.budget) * 100 : null)}</td>
                      </tr>);
                  })}
                </tbody>
              </table>
            ) : view.lines.length === 0 ? <div className="p-8 text-center text-muted-foreground text-sm">No rows at this level.</div> : (
              <table className="ledger" data-testid="table-variance">
                <thead><tr><th>{LABEL[level]}</th><th className="r">YTD Bud</th><th className="r">YTD Act</th><th className="r">YTD Var</th><th className="r">YTD %</th><th className="r">FY Bud</th><th className="r">FY {VERSION_LABEL[ver]}</th><th className="r">FY Var</th><th></th></tr></thead>
                <tbody>
                  {view.lines.map((l) => (
                    <tr key={l.key} className="cursor-pointer" onClick={() => setPath([...path, l.key])} data-testid={`row-drill-${l.key}`}>
                      <td className="font-medium text-primary">{l.key}</td>
                      <td className="r num">{money(l.ytdBudget)}</td><td className="r num">{money(l.ytdActual)}</td>
                      <td className={`r num ${toneClass(l.fav.ytd)}`}>{money(l.fav.ytd, { signed: true })}</td>
                      <td className={`r num ${toneClass(l.fav.ytd)}`}>{pct(l.ytdBudget ? (l.fav.ytd / l.ytdBudget) * 100 : null)}</td>
                      <td className="r num">{money(l.fyBudget)}</td><td className="r num">{money(l.fyLanding)}</td>
                      <td className={`r num ${toneClass(l.fav.fy)}`}>{money(l.fav.fy, { signed: true })}</td>
                      <td className="w-6"><ChevronRight className="h-3.5 w-3.5 text-muted-foreground" /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </Panel>
      )}
    </Page>
  );
}
