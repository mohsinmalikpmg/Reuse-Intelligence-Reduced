import { useMemo, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useGetRisks, useCreateRisk, useUpdateRisk, useDeleteRisk, useGetFinance, getGetRisksQueryKey, type Risk, type RiskInput } from "@workspace/api-client-react";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { Page, Panel, Kpi, LoadingBlock, ErrorBlock } from "@/components/shell";
import { ExportLinks } from "@/pages/dashboard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { money, compact, uniq, apiErr } from "@/lib/fin";

const EMPTY: RiskInput = { title: "", description: "", type: "Risk", costCentre: "", owner: "", impact: 0, status: "Open" };

export default function Risks() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const { data, isLoading, error, refetch } = useGetRisks();
  const fin = useGetFinance();
  const create = useCreateRisk(), update = useUpdateRisk(), del = useDeleteRisk();
  const [editing, setEditing] = useState<Risk | "new" | null>(null);
  const [form, setForm] = useState<RiskInput>(EMPTY);
  const [impactStr, setImpactStr] = useState("0");
  const [toDelete, setToDelete] = useState<Risk | null>(null);
  const [filter, setFilter] = useState<"all" | "Risk" | "Opportunity">("all");

  const centres = useMemo(() => (fin.data ? uniq(fin.data.rows.map((r) => r.costCentre)) : []), [fin.data]);
  const list = useMemo(() => (data ?? []).filter((r) => filter === "all" || r.type === filter), [data, filter]);
  const totals = useMemo(() => {
    const open = (data ?? []).filter((r) => r.status !== "Closed");
    const risk = open.filter((r) => r.type === "Risk").reduce((s, r) => s + r.impact, 0);
    const opp = open.filter((r) => r.type === "Opportunity").reduce((s, r) => s + r.impact, 0);
    return { risk, opp, net: opp - risk, n: open.length };
  }, [data]);

  const openEdit = (r: Risk | "new") => {
    setEditing(r);
    const f = r === "new" ? EMPTY : { title: r.title, description: r.description, type: r.type, costCentre: r.costCentre, owner: r.owner, impact: r.impact, status: r.status };
    setForm(f); setImpactStr(String(f.impact));
  };
  const done = (msg: string) => { qc.invalidateQueries({ queryKey: getGetRisksQueryKey() }); toast({ title: msg }); };
  const onErr = (e: unknown) => toast({ title: "Save failed", description: apiErr(e), variant: "destructive" });

  const submit = () => {
    const impact = Number(impactStr);
    if (!form.title.trim()) { toast({ title: "Title is required", variant: "destructive" }); return; }
    if (!Number.isFinite(impact) || impact < 0) { toast({ title: "Impact must be a non-negative number", variant: "destructive" }); return; }
    const payload = { ...form, title: form.title.trim(), impact };
    if (editing === "new") create.mutate({ data: payload }, { onSuccess: () => { setEditing(null); done("Entry added"); }, onError: onErr });
    else if (editing) update.mutate({ id: editing.id, data: payload }, { onSuccess: () => { setEditing(null); done("Entry updated"); }, onError: onErr });
  };
  const pending = create.isPending || update.isPending;

  return (
    <Page eyebrow="Register" title="Risks & opportunities"
      actions={<><ExportLinks kind="risks" /><Button size="sm" onClick={() => openEdit("new")} data-testid="button-add-risk"><Plus className="h-4 w-4 mr-1" />Add entry</Button></>}>
      {isLoading ? <LoadingBlock /> : error ? <ErrorBlock error={error} onRetry={() => refetch()} /> : (
        <div className="space-y-5">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <Kpi testid="kpi-open-items" label="Open items" value={String(totals.n)} />
            <Kpi testid="kpi-risk-exposure" label="Open risk exposure" value={compact(totals.risk)} tone="unfav" />
            <Kpi testid="kpi-opportunity" label="Open opportunities" value={compact(totals.opp)} tone="fav" />
            <Kpi testid="kpi-net" label="Net (opps − risks)" value={money(totals.net, { signed: true })} tone={totals.net >= 0 ? "fav" : "unfav"} />
          </div>
          <Panel title="Register" note="Seeded from the finance data; edits persist to the server."
            right={<Select value={filter} onValueChange={(v) => setFilter(v as typeof filter)}><SelectTrigger className="h-8 w-40 text-[12px]" data-testid="select-type-filter"><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="all">All types</SelectItem><SelectItem value="Risk">Risks</SelectItem><SelectItem value="Opportunity">Opportunities</SelectItem></SelectContent></Select>}>
            <div className="overflow-auto">
              {list.length === 0 ? (
                <div className="p-10 text-center"><div className="eyebrow">Register empty</div><p className="text-sm text-muted-foreground mt-2">No entries match. Add the first one to start tracking exposure.</p></div>
              ) : (
                <table className="ledger" data-testid="table-risks">
                  <thead><tr><th>Type</th><th>Title</th><th>Centre</th><th>Owner</th><th>Status</th><th>Source</th><th className="r">Impact</th><th></th></tr></thead>
                  <tbody>
                    {list.map((r) => (
                      <tr key={r.id} data-testid={`row-risk-${r.id}`}>
                        <td><span className={`text-[10.5px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-sm ${r.type === "Risk" ? "bg-destructive/10 unfav" : "bg-emerald-700/10 fav"}`}>{r.type === "Risk" ? "Risk" : "Opp"}</span></td>
                        <td className="max-w-[340px] whitespace-normal"><div className="font-medium">{r.title}</div>{r.description && <div className="text-[11.5px] text-muted-foreground line-clamp-2">{r.description}</div>}</td>
                        <td>{r.costCentre || "—"}</td><td>{r.owner || "—"}</td>
                        <td><span className={`text-[11.5px] ${r.status === "Closed" ? "text-muted-foreground line-through" : r.status === "Mitigating" ? "text-chart-3" : "text-primary font-medium"}`}>{r.status}</span></td>
                        <td className="text-muted-foreground text-[11.5px]">{r.source}</td>
                        <td className={`r num ${r.type === "Risk" ? "unfav" : "fav"}`}>{r.type === "Risk" ? `(${money(r.impact)})` : money(r.impact)}</td>
                        <td className="r">
                          <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => openEdit(r)} data-testid={`button-edit-risk-${r.id}`}><Pencil className="h-3.5 w-3.5" /></Button>
                          <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => setToDelete(r)} data-testid={`button-delete-risk-${r.id}`}><Trash2 className="h-3.5 w-3.5" /></Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </Panel>
        </div>
      )}

      <Dialog open={!!editing} onOpenChange={(o) => !o && setEditing(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle className="font-serif text-primary">{editing === "new" ? "New register entry" : "Edit register entry"}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2 space-y-1.5"><Label className="eyebrow">Title</Label><Input maxLength={200} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} data-testid="input-risk-title" /></div>
            <div className="col-span-2 space-y-1.5"><Label className="eyebrow">Description</Label><Textarea rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} data-testid="input-risk-description" /></div>
            <div className="space-y-1.5"><Label className="eyebrow">Type</Label>
              <Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v as RiskInput["type"] })}><SelectTrigger data-testid="select-risk-type"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="Risk">Risk</SelectItem><SelectItem value="Opportunity">Opportunity</SelectItem></SelectContent></Select></div>
            <div className="space-y-1.5"><Label className="eyebrow">Status</Label>
              <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as RiskInput["status"] })}><SelectTrigger data-testid="select-risk-status"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="Open">Open</SelectItem><SelectItem value="Mitigating">Mitigating</SelectItem><SelectItem value="Closed">Closed</SelectItem></SelectContent></Select></div>
            <div className="space-y-1.5"><Label className="eyebrow">Cost centre</Label>
              <Select value={form.costCentre || "none"} onValueChange={(v) => setForm({ ...form, costCentre: v === "none" ? "" : v })}><SelectTrigger data-testid="select-risk-centre"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="none">Unassigned</SelectItem>{[...new Set([...centres, form.costCentre].filter(Boolean))].map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent></Select></div>
            <div className="space-y-1.5"><Label className="eyebrow">Owner</Label><Input value={form.owner} onChange={(e) => setForm({ ...form, owner: e.target.value })} data-testid="input-risk-owner" /></div>
            <div className="col-span-2 space-y-1.5"><Label className="eyebrow">Full-year impact ($)</Label><Input className="num" type="number" min={0} value={impactStr} onChange={(e) => setImpactStr(e.target.value)} data-testid="input-risk-impact" /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditing(null)} data-testid="button-cancel-risk">Cancel</Button>
            <Button onClick={submit} disabled={pending} data-testid="button-save-risk">{pending ? "Saving…" : "Save"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!toDelete} onOpenChange={(o) => !o && setToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Delete “{toDelete?.title}”?</AlertDialogTitle><AlertDialogDescription>This removes the entry from the register permanently.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" data-testid="button-confirm-delete"
              onClick={() => toDelete && del.mutate({ id: toDelete.id }, { onSuccess: () => { setToDelete(null); done("Entry deleted"); }, onError: onErr })}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Page>
  );
}
