import { useMemo, useState } from "react";
import { useGetFinance } from "@workspace/api-client-react";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar, Cell, ReferenceLine, Legend } from "recharts";
import { Download, Flag } from "lucide-react";
import { Page, Panel, Kpi, LoadingBlock, ErrorBlock, Seg } from "@/components/shell";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MONTHS, VERSION_LABEL, type Version, money, compact, pct, toneClass, groupLines, pnl, centreFlags, uniq, favVar, landing } from "@/lib/fin";

const NAVY = "hsl(217 58% 24%)", GREY = "hsl(212 15% 62%)", SKY = "hsl(205 70% 46%)", FAV = "hsl(152 55% 30%)", UNFAV = "hsl(356 66% 44%)";

export function ExportLinks({ kind }: { kind: "landing" | "risks" }) {
  return (
    <div title={kind === "landing" ? "Export whole-company FY2026 Q3 baseline OpEx landing" : "Export current register"} className="inline-flex border border-input rounded bg-card text-[12px]">
      {(["csv", "xlsx"] as const).map((f, i) => (
        <a key={f} href={`/api/export/${kind}?format=${f}`} data-testid={`link-export-${kind}-${f}`}
          className={`px-3 py-1.5 inline-flex items-center gap-1.5 hover:bg-accent ${i ? "border-l border-input" : ""}`}>
          <Download className="h-3.5 w-3.5" />{f.toUpperCase()}
        </a>
      ))}
    </div>
  );
}

export default function Dashboard() {
  const { data, isLoading, error, refetch } = useGetFinance();
  const [bu, setBu] = useState("all");
  const [ver, setVer] = useState<Version>("q3");

  const calc = useMemo(() => {
    if (!data) return null;
    const t = data.actualThroughMonth;
    const rows = bu === "all" ? data.rows : data.rows.filter((r) => r.businessUnit === bu);
    const ytdRows = rows.filter((r) => r.month <= t);
    const ytdA = pnl(ytdRows, (r) => r.actual ?? 0), ytdB = pnl(ytdRows, (r) => r.budget);
    const fyL = pnl(rows, (r) => landing(r, ver)), fyB = pnl(rows, (r) => r.budget);
    const monthly = MONTHS.map((m, i) => {
      const mr = rows.filter((r) => r.month === i + 1);
      const p = (f: (r: typeof mr[number]) => number) => pnl(mr, f).profit;
      return { m, Budget: p((r) => r.budget), Actual: i + 1 <= t ? p((r) => r.actual ?? 0) : null, Forecast: p((r) => landing(r, ver)) };
    });
    // waterfall: cumulative YTD profit variance by BU
    const buLines = groupLines(data.rows.filter((r) => r.month <= t), t, ver, (r) => r.businessUnit);
    let run = 0;
    const wf = buLines.map((b) => { const v = b.fav.ytd; const start = run; run += v; return { name: b.key, range: [Math.min(start, run), Math.max(start, run)], v, end: run }; });
    wf.push({ name: "Total", range: [Math.min(0, run), Math.max(0, run)], v: run, end: run });
    const ytdTable = groupLines(rows, t, ver, (r) => `${r.businessUnit}|${r.account}`);
    const flags = centreFlags(rows, t, data.settings, ver);
    return { t, ytdA, ytdB, fyL, fyB, monthly, wf, ytdTable, flags, bus: uniq(data.rows.map((r) => r.businessUnit)) };
  }, [data, bu, ver]);

  return (
    <Page eyebrow={data ? `FY${data.fiscalYear} · actuals Jan–${MONTHS[data.actualThroughMonth - 1]}` : "Overview"} title="YTD performance & full-year landing"
      actions={<>
        <Select value={bu} onValueChange={setBu}>
          <SelectTrigger className="w-48 h-8 text-[12px]" data-testid="select-bu"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="all">All business units</SelectItem>{calc?.bus.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}</SelectContent>
        </Select>
        <Seg value={ver} onChange={setVer} testid="toggle-version" options={[{ value: "q3", label: "Q3 Fcst" }, { value: "q2", label: "Q2 Fcst" }]} />
        <ExportLinks kind="landing" />
      </>}>
      {isLoading ? <LoadingBlock /> : error || !calc ? <ErrorBlock error={error} onRetry={() => refetch()} /> : (
        <div className="space-y-5">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <Kpi testid="kpi-ytd-revenue" label="YTD Revenue" value={compact(calc.ytdA.revenue)} tone={toneClass(calc.ytdA.revenue - calc.ytdB.revenue)}
              sub={<>vs bud {compact(calc.ytdB.revenue)} · <span className={toneClass(calc.ytdA.revenue - calc.ytdB.revenue)}>{pct(calc.ytdB.revenue ? (calc.ytdA.revenue / calc.ytdB.revenue - 1) * 100 : null)}</span></>} />
            <Kpi testid="kpi-ytd-opex" label="YTD OpEx" value={compact(calc.ytdA.opex)} tone={toneClass(calc.ytdB.opex - calc.ytdA.opex)}
              sub={<>vs bud {compact(calc.ytdB.opex)} · <span className={toneClass(calc.ytdB.opex - calc.ytdA.opex)}>{money(calc.ytdB.opex - calc.ytdA.opex, { signed: true })}</span></>} />
            <Kpi testid="kpi-ytd-profit" label="YTD Profit" value={compact(calc.ytdA.profit)} tone={toneClass(calc.ytdA.profit - calc.ytdB.profit)}
              sub={<>var {money(calc.ytdA.profit - calc.ytdB.profit, { signed: true })}</>} />
            <Kpi testid="kpi-fy-profit" label={`FY Landing · ${VERSION_LABEL[ver]}`} value={compact(calc.fyL.profit)} tone={toneClass(calc.fyL.profit - calc.fyB.profit)}
              sub={<>budget {compact(calc.fyB.profit)} · <span className={toneClass(calc.fyL.profit - calc.fyB.profit)}>{money(calc.fyL.profit - calc.fyB.profit, { signed: true })}</span></>} />
          </div>

          <div className="grid lg:grid-cols-5 gap-5">
            <Panel className="lg:col-span-3" title="Monthly profit — actual, budget, forecast" note={`Profit = Revenue − COGS − OpEx. Forecast line is ${VERSION_LABEL[ver]}.`}>
              <div className="h-72 p-3" data-testid="chart-monthly">
                <ResponsiveContainer>
                  <LineChart data={calc.monthly} margin={{ top: 8, right: 12, left: 4, bottom: 0 }}>
                    <CartesianGrid stroke="hsl(214 22% 90%)" vertical={false} />
                    <XAxis dataKey="m" tick={{ fontSize: 11 }} tickLine={false} axisLine={{ stroke: "hsl(214 22% 80%)" }} />
                    <YAxis tickFormatter={compact} tick={{ fontSize: 11, fontFamily: "IBM Plex Mono" }} width={64} tickLine={false} axisLine={false} />
                    <Tooltip formatter={(v: number) => money(v)} contentStyle={{ fontSize: 12, fontFamily: "IBM Plex Mono", borderRadius: 4 }} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    <ReferenceLine x={MONTHS[calc.t - 1]} stroke={GREY} strokeDasharray="2 3" label={{ value: "Actuals close", fontSize: 10, fill: GREY, position: "insideTopRight" }} />
                    <Line dataKey="Budget" stroke={GREY} strokeDasharray="5 4" dot={false} strokeWidth={1.5} />
                    <Line dataKey="Forecast" name={VERSION_LABEL[ver]} stroke={SKY} dot={false} strokeWidth={1.5} />
                    <Line dataKey="Actual" stroke={NAVY} strokeWidth={2.4} dot={{ r: 2.5 }} connectNulls={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </Panel>
            <Panel className="lg:col-span-2" title="Cumulative YTD profit variance by BU" note="Waterfall bridge; green favourable, red unfavourable, total anchored at zero.">
              <div className="h-72 p-3" data-testid="chart-waterfall">
                <ResponsiveContainer>
                  <BarChart data={calc.wf} margin={{ top: 8, right: 8, left: 4, bottom: 0 }}>
                    <CartesianGrid stroke="hsl(214 22% 90%)" vertical={false} />
                    <XAxis dataKey="name" tick={{ fontSize: 10 }} interval={0} tickLine={false} />
                    <YAxis tickFormatter={compact} tick={{ fontSize: 11, fontFamily: "IBM Plex Mono" }} width={60} tickLine={false} axisLine={false} />
                    <ReferenceLine y={0} stroke="hsl(217 45% 14%)" />
                    <Tooltip cursor={{ fill: "hsl(212 45% 91% / .5)" }} content={({ payload }) => {
                      const p = payload?.[0]?.payload as (typeof calc.wf)[number] | undefined;
                      if (!p) return null;
                      return <div className="bg-card border rounded px-2.5 py-1.5 text-[12px] num"><div className="font-sans font-semibold">{p.name}</div><div className={toneClass(p.v)}>{money(p.v, { signed: true })}</div><div className="text-muted-foreground">running {money(p.end)}</div></div>;
                    }} />
                    <Bar dataKey="range">
                      {calc.wf.map((d, i) => <Cell key={i} fill={i === calc.wf.length - 1 ? NAVY : d.v >= 0 ? FAV : UNFAV} />)}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </Panel>
          </div>

          <div className="grid lg:grid-cols-5 gap-5">
            <Panel className="lg:col-span-3" title="YTD and full-year by business unit & account" note="Variance shown favourable-positive. Revenue favourability reversed.">
              <div className="overflow-auto max-h-[460px]">
                <table className="ledger" data-testid="table-ytd-fy">
                  <thead><tr><th>Business unit</th><th>Account</th><th className="r">YTD Bud</th><th className="r">YTD Act</th><th className="r">YTD Var / %</th><th className="r">FY Bud</th><th className="r">FY {ver.toUpperCase()}</th><th className="r">FY Var / %</th></tr></thead>
                  <tbody>
                    {calc.ytdTable.map((l) => { const [b, a] = l.key.split("|"); return (
                      <tr key={l.key} data-testid={`row-ytd-${l.key}`}>
                        <td>{b}</td><td className="text-muted-foreground">{a}</td>
                        <td className="r num">{money(l.ytdBudget)}</td><td className="r num">{money(l.ytdActual)}</td>
                        <td className={`r num ${toneClass(l.fav.ytd)}`}>{money(l.fav.ytd, { signed: true })}<div className="text-[10px]">{pct(l.ytdBudget ? l.fav.ytd / l.ytdBudget * 100 : null)}</div></td>
                        <td className="r num">{money(l.fyBudget)}</td><td className="r num">{money(l.fyLanding)}</td>
                        <td className={`r num ${toneClass(l.fav.fy)}`}>{money(l.fav.fy, { signed: true })}<div className="text-[10px]">{pct(l.fyBudget ? l.fav.fy / l.fyBudget * 100 : null)}</div></td>
                      </tr>); })}
                  </tbody>
                  <tfoot><tr><td colSpan={2}>Profit</td>
                    <td className="r num">{money(calc.ytdB.profit)}</td><td className="r num">{money(calc.ytdA.profit)}</td>
                    <td className={`r num ${toneClass(calc.ytdA.profit - calc.ytdB.profit)}`}>{money(calc.ytdA.profit - calc.ytdB.profit, { signed: true })}</td>
                    <td className="r num">{money(calc.fyB.profit)}</td><td className="r num">{money(calc.fyL.profit)}</td>
                    <td className={`r num ${toneClass(calc.fyL.profit - calc.fyB.profit)}`}>{money(calc.fyL.profit - calc.fyB.profit, { signed: true })}</td></tr></tfoot>
                </table>
              </div>
            </Panel>
            <Panel className="lg:col-span-2" title="Cost centre exceptions" note={`Flag when FY forecast OpEx overrun > ${data!.settings.percentThreshold}% or > $${money(data!.settings.dollarThreshold)}.`}
              right={<span className="text-[11px] num text-destructive" data-testid="text-flag-count">{calc.flags.filter((f) => f.flagged).length} flagged</span>}>
              <div className="overflow-auto max-h-[460px]">
                <table className="ledger" data-testid="table-flags">
                  <thead><tr><th></th><th>Centre</th><th className="r">FY Bud</th><th className="r">FY Fcst</th><th className="r">Over</th><th className="r">%</th></tr></thead>
                  <tbody>
                    {calc.flags.map((f) => (
                      <tr key={f.bu + f.centre} className={f.flagged ? "bg-destructive/[.04]" : ""} data-testid={`row-flag-${f.centre}`}>
                        <td className="w-6">{f.flagged && <Flag className="h-3.5 w-3.5 text-destructive" aria-label={f.reason} />}</td>
                        <td><div>{f.centre}</div><div className="text-[10.5px] text-muted-foreground">{f.bu}{f.flagged ? ` · ${f.reason}` : ""}</div></td>
                        <td className="r num">{money(f.budget)}</td><td className="r num">{money(f.actual)}</td>
                        <td className={`r num ${toneClass(favVar("expense", f.budget, f.actual))}`}>{money(f.over, { signed: true })}</td>
                        <td className={`r num ${toneClass(-f.overPct)}`}>{pct(f.overPct)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Panel>
          </div>
        </div>
      )}
    </Page>
  );
}
