import { useEffect, useRef, useState } from "react";
import { useAskAssistant, type ChatAnswer } from "@workspace/api-client-react";
import { ArrowUp } from "lucide-react";
import { Page } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { money, toneClass, apiErr } from "@/lib/fin";

type Msg = { role: "user"; text: string } | { role: "agent"; a: ChatAnswer } | { role: "error"; text: string; q: string };
const PROMPTS = ["Which cost centres are most over budget YTD?", "What is the full-year profit landing vs budget?", "What drove the movement from Q2 to Q3 forecast?", "Where is revenue tracking behind budget?"];

export default function Assistant() {
  const ask = useAskAssistant();
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [text, setText] = useState("");
  const end = useRef<HTMLDivElement>(null);
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, ask.isPending]);

  const send = (q: string) => {
    const message = q.trim();
    if (!message || ask.isPending) return;
    setMsgs((m) => [...m, { role: "user", text: message }]); setText("");
    ask.mutate({ data: { message: message.slice(0, 2000) } }, {
      onSuccess: (a) => setMsgs((m) => [...m, { role: "agent", a }]),
      onError: (e) => setMsgs((m) => [...m, { role: "error", text: apiErr(e), q: message }]),
    });
  };

  return (
    <Page eyebrow="Assistant" title="Ask the ledger">
      <div className="max-w-4xl mx-auto flex flex-col min-h-[calc(100dvh-200px)]">
        <div className="flex-1 space-y-5 pb-6" data-testid="list-messages">
          {msgs.length === 0 && (
            <div className="border border-dashed border-input rounded-md p-6">
              <div className="eyebrow">Evidence-led answers</div>
              <p className="text-sm text-muted-foreground mt-2">Every answer cites the budget lines it used. Try:</p>
              <div className="flex flex-wrap gap-2 mt-4">
                {PROMPTS.map((p, i) => <button key={p} onClick={() => send(p)} className="text-[12.5px] px-3 py-1.5 border border-input rounded bg-card hover:bg-accent" data-testid={`button-prompt-${i}`}>{p}</button>)}
              </div>
            </div>
          )}
          {msgs.map((m, i) => m.role === "user" ? (
            <div key={i} className="flex justify-end rise"><div className="bg-primary text-primary-foreground rounded-md px-4 py-2.5 text-sm max-w-[80%]" data-testid={`text-user-${i}`}>{m.text}</div></div>
          ) : m.role === "error" ? (
            <div key={i} className="border border-destructive/40 bg-destructive/5 rounded-md px-4 py-3 text-sm rise">
              <span className="text-destructive">{m.text}</span>
              <Button size="sm" variant="outline" className="ml-3 h-7" onClick={() => send(m.q)} data-testid={`button-retry-${i}`}>Retry</Button>
            </div>
          ) : (
            <article key={i} className="bg-card border border-card-border rounded-md rise" data-testid={`card-answer-${i}`}>
              <div className="px-4 pt-3 flex items-center gap-2"><span className="eyebrow">Answer</span><span className="text-[10px] uppercase tracking-wider border border-input rounded-sm px-1.5 text-muted-foreground" data-testid={`text-mode-${i}`}>{m.a.mode}</span></div>
              <p className="px-4 py-2.5 text-[14px] leading-relaxed whitespace-pre-wrap">{m.a.answer}</p>
              {m.a.evidence.length > 0 && (
                <div className="overflow-auto border-t border-border">
                  <table className="ledger" data-testid={`table-evidence-${i}`}>
                    <thead><tr><th>Evidence</th><th className="r">Baseline*</th><th className="r">Value</th><th className="r">Value − baseline</th><th>Driver</th></tr></thead>
                    <tbody>{m.a.evidence.map((e, j) => (
                      <tr key={j}><td className="font-medium">{e.label}</td><td className="r num">{money(e.budget)}</td><td className="r num">{money(e.value)}</td>
                        <td className={`r num ${toneClass(m.a.calculation.startsWith("SUM(Q3 Forecast revenue)") ? e.variance : -e.variance)}`}>{money(e.variance, { signed: true })}</td><td className="text-muted-foreground whitespace-normal min-w-[200px]">{e.driver}</td></tr>
                    ))}</tbody>
                  </table>
                  <p className="px-4 py-2 text-xs text-muted-foreground">*Baseline and value definitions are shown in the calculation below. Red is unfavourable; green is favourable.</p>
                </div>
              )}
              {m.a.calculation && <details className="border-t border-border px-4 py-2.5"><summary className="eyebrow cursor-pointer">Calculation</summary><pre className="num text-[11.5px] whitespace-pre-wrap mt-2 text-foreground/80">{m.a.calculation}</pre></details>}
            </article>
          ))}
          {ask.isPending && <div className="space-y-2"><Skeleton className="h-4 w-2/3" /><Skeleton className="h-4 w-1/2" /><Skeleton className="h-24 w-full" /></div>}
          <div ref={end} />
        </div>
        <form className="sticky bottom-4 bg-card border border-input rounded-md p-2 flex gap-2 items-end shadow-sm" onSubmit={(e) => { e.preventDefault(); send(text); }}>
          <Textarea rows={2} maxLength={2000} value={text} onChange={(e) => setText(e.target.value)} placeholder="Ask about variances, landings, drivers…" className="border-0 shadow-none focus-visible:ring-0 resize-none"
            onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(text); } }} data-testid="input-chat" />
          <Button type="submit" size="icon" disabled={!text.trim() || ask.isPending} data-testid="button-send"><ArrowUp className="h-4 w-4" /></Button>
        </form>
      </div>
    </Page>
  );
}
