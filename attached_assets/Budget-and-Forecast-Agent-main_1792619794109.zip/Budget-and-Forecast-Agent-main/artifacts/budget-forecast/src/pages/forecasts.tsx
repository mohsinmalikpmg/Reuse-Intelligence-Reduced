import { useMemo, useState } from "react";
import { useGetFinance, useCalculateProjection, type ScenarioInputMethod, type Projection } from "@workspace/api-client-react";
import { Calculator } from "lucide-react";
import { Page, Panel, Kpi, LoadingBlock, ErrorBlock, Seg } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { money, compact, toneClass, favVar, uniq, apiErr, MONTHS } from "@/lib/fin";

type Dim = "businessUnit" | "costCentre" | "account";

export default function Forecasts() {
  const { data, isLoading, error, refetch } = useGetFinance();
  const proj = useCalculateProjection();
  const { toast } = useToast();
  const [method, setMethod] = useState<ScenarioInputMethod>("forecast");
  const [rev, setRev] = useState("0");
  const [hc, setHc] = useState("0");
  const [account, setAccount] = useState("");
  const [adj, setAdj] = useState("0");
  const [result, setResult] = useState<Projection | null>(null);
  const [dim, setDim] = useState<Dim>("businessUnit");

  const accounts = useMemo(() => (data ? uniq(data.rows.map((r) => r.account)) : []), [data]);
  const compare = useMemo(() => {
    if (!data) return [];
    const m = new Map<string, { k: string; budget: number; q2: number; q3: number; fav: number }>();
    for (const r of data.rows) {
      const k = r[dim];
      const g = m.get(k) ?? { k, budget: 0, q2: 0, q3: 0, fav: 0 };
      g.budget += r.budget; g.q2 += r.q2; g.q3 += r.q3; g.fav += favVar(r.account, r.q2, r.q3);
      m.set(k, g);
    }
    return [...m.values()].sort((a, b) => a.fav - b.fav);
  }, [data, dim]);

  const run = () => {
    const nums = [rev, hc, adj].map(Number);
    if (nums.some((n) => !Number.isFinite(n))) { toast({ title: "Inputs must be numeric", variant: "destructive" }); return; }
    proj.mutate({ data: { method, revenueGrowth: nums[0], headcountCost: nums[1], account: account === "none" ? "" : account, accountAdjustment: nums[2] } }, {
      onSuccess: (p) => setResult(p),
      onError: (e) => toast({ title: "Projection failed", description: apiErr(e), variant: "destructive" }),
    });
  };

  const changed = useMemo(() => {
    if (!result || !data) return [];
    const base = new Map(data.rows.map((r) => [`${r.businessUnit}|${r.costCentre}|${r.account}|${r.month}`, r.q3]));
    return result.rows.filter((r) => r.month > data.actualThroughMonth).map((r) => ({ r, before: base.get(`${r.businessUnit}|${r.costCentre}|${r.account}|${r.month}`) ?? 0 }))
      .filter((x) => Math.abs(x.r.q3 - x.before) > 0.5);
  }, [result, data]);

  return (
    <Page eyebrow="Forecasting" title="Run-rate, scenarios & Q2 → Q3 movement">
      {isLoading ? <LoadingBlock /> : error || !data ? <ErrorBlock error={error} onRetry={() => refetch()} /> : (
        <div className="space-y-5">
          <div className="grid lg:grid-cols-3 gap-5">
            <Panel title="Scenario inputs" note={`Applies to remaining months ${MONTHS[data.actualThroughMonth]}–Dec only.`}>
              <div className="p-4 space-y-4">
                <div className="space-y-1.5">
                  <Label className="eyebrow">Baseline method</Label>
                  <Seg value={method} onChange={setMethod} testid="toggle-method" options={[{ value: "forecast", label: "Q3 forecast" }, { value: "ytd", label: "YTD run-rate" }, { value: "last3", label: "Last 3 months" }]} />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5"><Label className="eyebrow">Revenue growth %</Label><Input className="num" type="number" step="0.1" value={rev} onChange={(e) => setRev(e.target.value)} data-testid="input-revenue-growth" /></div>
                  <div className="space-y-1.5"><Label className="eyebrow">Headcount cost %</Label><Input className="num" type="number" step="0.1" value={hc} onChange={(e) => setHc(e.target.value)} data-testid="input-headcount-cost" /></div>
                </div>
                <div className="space-y-1.5">
                  <Label className="eyebrow">Account adjustment</Label>
                  <Select value={account || "none"} onValueChange={setAccount}>
                    <SelectTrigger data-testid="select-account"><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="none">No account adjustment</SelectItem>{accounts.map((a) => <SelectItem key={a} value={a}>{a}</SelectItem>)}</SelectContent>
                  </Select>
                  <Input className="num" type="number" step="1000" value={adj} onChange={(e) => setAdj(e.target.value)} disabled={!account || account === "none"} data-testid="input-account-adjustment" placeholder="Total $ spread over remaining months" />
                  <p className="text-[11px] text-muted-foreground">Total dollars, spread evenly across remaining months.</p>
                </div>
                <Button className="w-full" onClick={run} disabled={proj.isPending} data-testid="button-run-scenario">
                  <Calculator className="h-4 w-4 mr-2" />{proj.isPending ? "Calculating…" : "Calculate projection"}
                </Button>
              </div>
            </Panel>
            <div className="lg:col-span-2 space-y-5">
              {!result ? (
                <div className="h-full min-h-[280px] border border-dashed border-input rounded-md grid place-items-center text-center p-8">
                  <div><div className="eyebrow">No scenario run</div><p className="text-sm text-muted-foreground mt-2 max-w-sm">Choose a baseline method and drivers, then calculate. Results come from the projection engine, with the calculation trail shown.</p></div>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    {([["Revenue", result.revenue, result.baselineRevenue, 1], ["OpEx", result.opex, result.baselineOpex, -1], ["Profit", result.profit, result.baselineProfit, 1]] as const).map(([l, v, b, s]) => (
                      <Kpi key={l} testid={`kpi-scenario-${l.toLowerCase()}`} label={`Scenario ${l}`} value={compact(v)} tone={toneClass((v - b) * s)}
                        sub={<>baseline {compact(b)} · <span className={toneClass((v - b) * s)}>{money(v - b, { signed: true })}</span></>} />
                    ))}
                  </div>
                  <Panel title="Calculation trail">
                    <pre className="p-4 text-[12px] num whitespace-pre-wrap text-foreground/85" data-testid="text-calculation">{result.calculation}</pre>
                  </Panel>
                  <Panel title="Adjusted forecast lines" note={`${changed.length} remaining-month lines differ from current Q3.`}>
                    <div className="overflow-auto max-h-80">
                      <table className="ledger" data-testid="table-scenario-rows">
                        <thead><tr><th>BU</th><th>Centre</th><th>Account</th><th>Month</th><th className="r">Q3 current</th><th className="r">Scenario</th><th className="r">Change</th></tr></thead>
                        <tbody>
                          {changed.length === 0 ? <tr><td colSpan={7} className="text-center text-muted-foreground py-6">No lines changed versus current Q3 forecast.</td></tr> :
                            changed.map(({ r, before }, i) => (
                              <tr key={i}><td>{r.businessUnit}</td><td>{r.costCentre}</td><td className="text-muted-foreground">{r.account}</td><td>{MONTHS[r.month - 1]}</td>
                                <td className="r num">{money(before)}</td><td className="r num">{money(r.q3)}</td>
                                <td className={`r num ${toneClass(favVar(r.account, before, r.q3))}`}>{money(r.q3 - before, { signed: true })}</td></tr>
                            ))}
                        </tbody>
                      </table>
                    </div>
                  </Panel>
                </>
              )}
            </div>
          </div>

          <Panel title="Q2 vs Q3 forecast — full year" note="Movement = Q3 − Q2; colour shows favourability (revenue reversed). Sorted most unfavourable first."
            right={<Seg value={dim} onChange={setDim} testid="toggle-compare-dim" options={[{ value: "businessUnit", label: "Business unit" }, { value: "costCentre", label: "Cost centre" }, { value: "account", label: "Account" }]} />}>
            <div className="overflow-auto max-h-[480px]">
              <table className="ledger" data-testid="table-q2-q3">
                <thead><tr><th>{dim === "businessUnit" ? "Business unit" : dim === "costCentre" ? "Cost centre" : "Account"}</th><th className="r">FY Budget</th><th className="r">Q2 Fcst</th><th className="r">Q3 Fcst</th><th className="r">Q3 − Q2</th><th className="r">Fav / (Unfav)</th></tr></thead>
                <tbody>
                  {compare.map((c) => (
                    <tr key={c.k} data-testid={`row-compare-${c.k}`}><td>{c.k}</td><td className="r num">{money(c.budget)}</td><td className="r num">{money(c.q2)}</td><td className="r num">{money(c.q3)}</td>
                      <td className="r num">{money(c.q3 - c.q2, { signed: true })}</td><td className={`r num font-medium ${toneClass(c.fav)}`}>{money(c.fav, { signed: true })}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Panel>
        </div>
      )}
    </Page>
  );
}
