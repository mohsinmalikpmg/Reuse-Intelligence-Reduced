import { useEffect, type ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { LayoutDashboard, TrendingUp, GitBranch, ShieldAlert, MessageSquareText, SlidersHorizontal, RefreshCw } from "lucide-react";
import { useHealthCheck, useGetFinance } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { apiErr } from "@/lib/fin";

const NAV = [
  { href: "/", label: "Overview", icon: LayoutDashboard },
  { href: "/forecasts", label: "Forecasts", icon: TrendingUp },
  { href: "/variance", label: "Variance", icon: GitBranch },
  { href: "/risks", label: "Risks & Opps", icon: ShieldAlert },
  { href: "/assistant", label: "Assistant", icon: MessageSquareText },
  { href: "/settings", label: "Settings", icon: SlidersHorizontal },
];

export function Shell({ children }: { children: ReactNode }) {
  const [loc] = useLocation();
  const health = useHealthCheck();
  const fin = useGetFinance();
  const ok = health.data?.status === "ok" || (!!health.data && !health.isError);
  return (
    <div className="min-h-[100dvh] flex flex-col md:flex-row bg-background">
      <aside className="md:w-56 shrink-0 bg-sidebar text-sidebar-foreground md:min-h-[100dvh] md:sticky md:top-0 md:h-[100dvh] flex md:flex-col">
        <div className="px-5 py-5 hidden md:block border-b border-sidebar-border">
          <div className="font-serif text-[17px] text-white leading-tight">Budget &amp; Forecast</div>
          <div className="text-[10px] tracking-[.18em] uppercase text-sidebar-foreground/60 mt-1">FP&amp;A Agent · FY{fin.data?.fiscalYear ?? "—"}</div>
        </div>
        <nav className="flex md:flex-col gap-0.5 p-2 md:p-3 overflow-x-auto flex-1">
          {NAV.map((n) => {
            const active = n.href === "/" ? loc === "/" : loc.startsWith(n.href);
            return (
              <Link key={n.href} href={n.href} data-testid={`link-nav-${n.label.toLowerCase().replace(/\W+/g, "-")}`}
                className={`flex items-center gap-2.5 px-3 py-2 rounded text-[13px] whitespace-nowrap transition-colors ${active ? "bg-sidebar-accent text-white border-l-2 border-sidebar-primary" : "hover:bg-sidebar-accent/60 border-l-2 border-transparent"}`}>
                <n.icon className="h-4 w-4 opacity-80" />{n.label}
              </Link>
            );
          })}
        </nav>
        <div className="hidden md:block p-4 border-t border-sidebar-border text-[11px] space-y-1.5">
          <div className="flex items-center gap-2" data-testid="status-api">
            <span className={`h-1.5 w-1.5 rounded-full ${health.isLoading ? "bg-sidebar-foreground/40" : ok ? "bg-emerald-400" : "bg-rose-400"}`} />
            API {health.isLoading ? "checking" : ok ? "online" : "unreachable"}
          </div>
          {fin.data && <div className="text-sidebar-foreground/60">Actuals through {["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][fin.data.actualThroughMonth - 1]}</div>}
          {fin.data && <div className="text-sidebar-foreground/60">Assistant: {fin.data.assistantMode}</div>}
        </div>
      </aside>
      <main className="flex-1 min-w-0">{children}</main>
    </div>
  );
}

export function Page({ title, eyebrow, actions, children }: { title: string; eyebrow: string; actions?: ReactNode; children: ReactNode }) {
  useEffect(() => { document.title = `${title} · Budget & Forecast Agent`; }, [title]);
  return (
    <div className="px-4 md:px-8 py-6 md:py-8 max-w-[1440px] mx-auto">
      <header className="flex flex-wrap items-end justify-between gap-4 pb-5 mb-6 border-b border-foreground/80">
        <div>
          <div className="eyebrow">{eyebrow}</div>
          <h1 className="font-serif text-[28px] leading-tight mt-1 text-primary" data-testid="text-page-title">{title}</h1>
        </div>
        {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
      </header>
      {children}
    </div>
  );
}

export function Panel({ title, note, right, children, className = "" }: { title: string; note?: string; right?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`bg-card border border-card-border rounded-md rise ${className}`}>
      <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 border-b border-border">
        <div>
          <h2 className="text-[13px] font-semibold text-primary">{title}</h2>
          {note && <p className="text-[11.5px] text-muted-foreground mt-0.5">{note}</p>}
        </div>
        {right}
      </div>
      <div>{children}</div>
    </section>
  );
}

export function LoadingBlock() {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">{[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-24" />)}</div>
      <Skeleton className="h-72" /><Skeleton className="h-56" />
    </div>
  );
}

export function ErrorBlock({ error, onRetry }: { error: unknown; onRetry: () => void }) {
  return (
    <div className="border border-destructive/40 bg-destructive/5 rounded-md p-6 max-w-xl">
      <div className="eyebrow !text-destructive">Data unavailable</div>
      <p className="mt-2 text-sm">{apiErr(error)}</p>
      <Button size="sm" variant="outline" className="mt-4" onClick={onRetry} data-testid="button-retry"><RefreshCw className="h-3.5 w-3.5 mr-1.5" />Retry</Button>
    </div>
  );
}

export function Kpi({ label, value, sub, tone, testid }: { label: string; value: string; sub?: ReactNode; tone?: string; testid: string }) {
  return (
    <div className="bg-card border border-card-border rounded-md px-4 py-3.5 rise">
      <div className="eyebrow">{label}</div>
      <div className={`num text-[22px] font-semibold mt-1.5 ${tone ?? "text-primary"}`} data-testid={testid}>{value}</div>
      {sub && <div className="text-[11.5px] text-muted-foreground mt-1 num">{sub}</div>}
    </div>
  );
}

export function Seg<T extends string>({ value, options, onChange, testid }: { value: T; options: { value: NoInfer<T>; label: string }[]; onChange: (v: T) => void; testid: string }) {
  return (
    <div className="inline-flex border border-input rounded bg-card p-0.5" data-testid={testid}>
      {options.map((o) => (
        <button key={o.value} type="button" onClick={() => onChange(o.value)} data-testid={`${testid}-${o.value}`}
          className={`px-3 py-1 text-[12px] rounded-sm transition-colors ${value === o.value ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}>
          {o.label}
        </button>
      ))}
    </div>
  );
}
