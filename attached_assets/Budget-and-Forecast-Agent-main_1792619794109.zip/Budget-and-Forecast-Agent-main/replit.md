# Budget & Forecast Agent

A corporate FP&A demo with React and a Python FastAPI/SQLite financial engine. See README.md for formulas, the data model, reseeding and optional OpenAI setup.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the Python API server (managed PORT)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- Optional env: `OPENAI_API_KEY` for assistant intent classification; `BUDGET_DB_PATH` for SQLite location

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: FastAPI via artifacts/api-server/run-python.sh; Express scaffold is unused
- DB: SQLite as explicitly requested; PostgreSQL scaffold is unused
- Validation: Pydantic on backend; generated TypeScript client
- API codegen: Orval (from OpenAPI spec)
- Build: Vite frontend; uv-managed Python dependencies

## Where things live

_Populate as you build — short repo map plus pointers to the source-of-truth file for DB schema, API contracts, theme files, etc._

## Architecture decisions

_Populate as you build — non-obvious choices a reader couldn't infer from the code (3-5 bullets)._

## Product

_Describe the high-level user-facing capabilities of this app once they exist._

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

_Populate as you build — sharp edges, "always run X before Y" rules._

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
