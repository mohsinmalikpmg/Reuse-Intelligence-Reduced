# Budget & Forecast Agent

A working FP&A demo for fiscal year January–December 2026, with actuals closed through September. The application uses **React + Vite**, a **Python FastAPI** backend, and **SQLite**. All displayed financial data is synthetic demo data, not company data.

## Run

The managed workflows run the API and React frontend:

```sh
pnpm --filter @workspace/api-server run dev
pnpm --filter @workspace/budget-forecast run dev
```

The workflows supply the port and frontend base path. Dependencies are in `pyproject.toml` / `uv.lock` and the pnpm workspace lockfile. To install Python dependencies use `uv sync --frozen`; Node dependencies use `pnpm install`.

The Python server is started with `artifacts/api-server/run-python.sh`. The old scaffold's Express source is unused. The provided PostgreSQL library is also unused: the requested SQLite database is the source of financial data.

## Data model

SQLite defaults to `artifacts/api-server/finance/budget.sqlite3`. Set `BUDGET_DB_PATH` to use another writable path. Tables:

| Table | Grain / purpose |
| --- | --- |
| `cost_centres` | 12 cost centres, three each in Corporate, Operations, Sales & Marketing, Technology |
| `accounts` | Revenue, COGS, Salaries & Benefits, Contractors, Travel, Software & Licences, Facilities, Marketing, Professional Fees, Depreciation |
| `budget` | Cost centre × account × month, January–December 2026 |
| `actuals` | Same grain, January–September only |
| `forecast` | Version × cost centre × account × month, full-year Q2 and Q3 forecasts |
| `settings` | Persistent dollar and percent overrun thresholds |
| `risks` | Editable risk/opportunity register with owner, impact, status and source |

Ledger amounts are integer **cents**, converted to dollar values at the API boundary. Revenues and expenses are both stored as positive numbers. Q2 includes actuals through June and estimates thereafter; Q3 includes actuals through September and estimates thereafter. Future actuals are null, never zero.

### Built-in patterns

- Technology contractors run above plan and worsen in Q3.
- Sales & Marketing marketing spend is delayed in July–September and recovers in October–December: a timing variance, not a permanent saving.
- Corporate / Finance & Legal has a one-time $180,000 professional fees spike in June.
- Revenue is slightly below plan; Operations salaries are below budget.

Driver labels are simple rule-based indications, not causal proof.

## Calculations

- YTD = January–September; full year = January–December.
- OpEx excludes both Revenue **and COGS**.
- Profit = Revenue − COGS − OpEx.
- Dollar variance = actual or forecast minus budget. Positive expense variance is unfavourable; positive revenue variance is favourable.
- Flags use positive cost-centre OpEx variance **greater than percent threshold OR greater than dollar threshold**, default 5% / $50,000.
- Run-rate forecast = YTD actuals + 3 × average monthly actuals, using either January–September or July–September.
- Scenarios leave actuals unchanged. Revenue and headcount percentages apply only to October–December revenue and salaries. A specified account's dollar adjustment is a **total** across remaining months and cost centres, not a per-month adjustment.
- Risk records are generated once from material full-year Q3 vs budget account variances, then persist independently so analyst edits are not overwritten. Risks/opportunities are review items, not additional adjustments automatically applied to the forecast.
- Quarter questions refer to Q4 2026, the next open quarter after the September close.

## Assistant and optional OpenAI key

Without `OPENAI_API_KEY`, the assistant runs in explicitly labelled **rule-based** mode. It supports cost-centre risks, quarterly overruns, contractor run-rate impact, revenue vs plan, and Q2/Q3 changes. Known business-unit and cost-centre names can scope these questions. Unsupported questions return a limitation rather than fabricated figures.

To enable OpenAI, add `OPENAI_API_KEY` through the workspace's Secrets interface and restart the API workflow. Never put the key in source code or frontend environment variables. The server uses `gpt-4o-mini`.

OpenAI classifies the question into an allowlisted analysis; it does **not** write SQL, produce numbers, or write the final financial answer. The server queries SQLite and calculates the answer and evidence table. This deliberate constraint prevents LLM-generated figures. If OpenAI is unavailable, the response visibly identifies the rule-based fallback.

## Export

Both CSV and Excel `.xlsx` downloads are supported:

- `/api/export/landing?format=csv` or `format=xlsx` — full-year Q3 OpEx landing by business unit, with variance and percentage
- `/api/export/risks?format=csv` or `format=xlsx` — current persisted register

Exports identify FY2026 and Q3 explicitly. They are the whole-company baseline landing, not unsaved scenario results. Spreadsheet-formula characters in user-entered text are escaped.

## Reseed

Startup creates and seeds the database only when budget data is absent. To rebuild the original deterministic sample:

```sh
uv run python artifacts/api-server/finance/data.py --reset
```

**Warning:** `--reset` deletes the existing SQLite file, including all register edits and threshold changes. Stop the API first, back up the file if needed, run the command, then restart it. Running the same script without `--reset` preserves existing data.

## API contract

`lib/api-spec/openapi.yaml` defines the typed client contract. Regenerate after changes:

```sh
pnpm --filter @workspace/api-spec run codegen
```

FastAPI also serves its runtime API documentation at `/docs` on the backend service; the application's public proxy routes only `/api`.

## Scope and hosting

This is a single-team demo without authentication or access controls. Do not put sensitive company data in it on a public URL without adding authentication and authorization.

SQLite persists across local server restarts. A deployment's local filesystem should not be treated as durable shared storage: a new instance or publish may have a newly seeded database. Before production use, configure durable storage appropriate for SQLite with a single server instance, or explicitly migrate to a managed relational database. No migration is performed automatically.
